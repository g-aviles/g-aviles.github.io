# CS Course Plan Manager

An internal Angular application for Computer Science advisors to load named
course plans, retrieve a course and its relationships, compare spreadsheet
updates, create plan versions, and export the current version as CSV.

## Run locally

```bash
npm install
npm start
```

Open `http://localhost:4200`.

## Current prototype storage

The working prototype uses browser local storage behind `CoursePlanStore`.
This keeps the application immediately runnable without institutional
credentials. For production, replace the store's persistence methods with an
HTTP repository connected to the department's protected backend database. The
course indexing and graph algorithms do not need to change.

Use **Reset demo data** from developer tools by clearing the
`cs-course-plan-manager.plans.v1` local-storage key if needed.

## Import format

CSV and Excel (`.xlsx` or `.xls`) files may contain these headers:

- Course Number (also Course ID or Course Code)
- Course Title (also Title or Name)
- Prerequisites, separated by semicolons, commas, or pipes
- Credits

The import preview labels records as Added, Modified, Unchanged, Missing, or
Invalid. Missing records remain in the next version as inactive rather than
being silently deleted.

## Data structures and algorithms

| Capability | Structure or algorithm | Complexity |
| --- | --- | --- |
| Find one course | `Map<string, Course>` | Average O(1) |
| Retrieve prerequisites | Forward adjacency list | O(p) |
| Retrieve next courses | Reverse adjacency list | O(d) |
| Compare current and imported plans | Two hash maps | O(n + m) |
| Validate prerequisite cycles | Depth-first search | O(V + E) |
| Sort the catalog | Array sort | O(V log V) |

`CourseIndexService` builds the hash index and both directions of the
prerequisite graph whenever an advisor selects or updates a plan.
