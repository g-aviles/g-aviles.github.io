import { Injectable } from '@angular/core';
import * as XLSX from 'xlsx';
import { Course } from './models';

@Injectable({ providedIn: 'root' })
export class SpreadsheetService {
  async read(file: File): Promise<Course[]> {
    const bytes = await file.arrayBuffer();
    const workbook = XLSX.read(bytes, { type: 'array' });
    const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(firstSheet, {
      defval: '',
      raw: false,
    });

    return rows
      .map((row) => this.toCourse(row))
      .filter((course) => course.courseNumber || course.title);
  }

  private toCourse(row: Record<string, unknown>): Course {
    const normalizedEntries: Array<[string, string]> = Object.entries(row).map(
      ([key, value]) => [
        this.normalizeHeader(key),
        String(value ?? '').trim(),
      ],
    );
    const fields = new Map<string, string>(normalizedEntries);
    const number = this.normalizeNumber(
      this.first(fields, ['coursenumber', 'courseid', 'coursecode', 'course']),
    );
    const prerequisiteValue = this.first(fields, [
      'prerequisites',
      'prerequisite',
      'prereqs',
    ]);

    return {
      courseNumber: number,
      title: this.first(fields, ['coursetitle', 'title', 'name']).trim(),
      prerequisites: prerequisiteValue
        .split(/[;,|]/)
        .map((value) => this.normalizeNumber(value))
        .filter(Boolean),
      credits: Number(this.first(fields, ['credits', 'credit'])) || 3,
      active: true,
    };
  }

  private first(fields: Map<string, string>, aliases: string[]): string {
    for (const alias of aliases) {
      const value = fields.get(alias);
      if (value !== undefined) return value;
    }
    return '';
  }

  private normalizeHeader(value: string): string {
    return value.toLowerCase().replace(/[^a-z0-9]/g, '');
  }

  private normalizeNumber(value: string): string {
    return value.trim().toUpperCase().replace(/\s+/g, '');
  }
}
