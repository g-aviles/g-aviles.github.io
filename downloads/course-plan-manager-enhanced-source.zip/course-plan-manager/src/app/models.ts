export interface Course {
  courseNumber: string;
  title: string;
  prerequisites: string[];
  credits: number;
  active: boolean;
}

export interface CoursePlan {
  id: string;
  title: string;
  academicYear: string;
  status: 'Draft' | 'Active' | 'Archived';
  version: number;
  updatedAt: string;
  courses: Course[];
}

export type ChangeStatus =
  | 'Added'
  | 'Modified'
  | 'Unchanged'
  | 'Missing'
  | 'Invalid';

export interface CourseChange {
  courseNumber: string;
  status: ChangeStatus;
  previous?: Course;
  incoming?: Course;
  changedFields: string[];
  message?: string;
}

export interface ImportComparison {
  fileName: string;
  importedCourses: Course[];
  changes: CourseChange[];
  hasCycles: boolean;
  cyclePath: string[];
}
