import { Injectable } from '@angular/core';
import { Course } from './models';

@Injectable({ providedIn: 'root' })
export class CourseIndexService {
  private readonly coursesByNumber = new Map<string, Course>();
  private readonly prerequisitesByCourse = new Map<string, Set<string>>();
  private readonly nextCoursesByCourse = new Map<string, Set<string>>();

  load(courses: Course[]): void {
    this.clear();

    for (const original of courses) {
      const course = this.normalizeCourse(original);
      this.coursesByNumber.set(course.courseNumber, course);
      this.prerequisitesByCourse.set(
        course.courseNumber,
        new Set(course.prerequisites),
      );
    }

    for (const [courseNumber, prerequisites] of this.prerequisitesByCourse) {
      for (const prerequisite of prerequisites) {
        const dependents =
          this.nextCoursesByCourse.get(prerequisite) ?? new Set<string>();
        dependents.add(courseNumber);
        this.nextCoursesByCourse.set(prerequisite, dependents);
      }
    }
  }

  findCourse(courseNumber: string): Course | undefined {
    return this.coursesByNumber.get(this.normalizeNumber(courseNumber));
  }

  getPrerequisites(courseNumber: string): Course[] {
    return this.resolve(
      this.prerequisitesByCourse.get(this.normalizeNumber(courseNumber)),
    );
  }

  getNextCourses(courseNumber: string): Course[] {
    return this.resolve(
      this.nextCoursesByCourse.get(this.normalizeNumber(courseNumber)),
    );
  }

  getAllCourses(): Course[] {
    return [...this.coursesByNumber.values()].sort((a, b) =>
      a.courseNumber.localeCompare(b.courseNumber, undefined, { numeric: true }),
    );
  }

  findCycle(): string[] {
    const state = new Map<string, 'visiting' | 'visited'>();
    const path: string[] = [];

    const visit = (courseNumber: string): string[] | undefined => {
      if (state.get(courseNumber) === 'visiting') {
        const cycleStart = path.indexOf(courseNumber);
        return [...path.slice(cycleStart), courseNumber];
      }

      if (state.get(courseNumber) === 'visited') {
        return undefined;
      }

      state.set(courseNumber, 'visiting');
      path.push(courseNumber);

      for (const prerequisite of this.prerequisitesByCourse.get(courseNumber) ?? []) {
        if (!this.coursesByNumber.has(prerequisite)) {
          continue;
        }
        const cycle = visit(prerequisite);
        if (cycle) {
          return cycle;
        }
      }

      path.pop();
      state.set(courseNumber, 'visited');
      return undefined;
    };

    for (const courseNumber of this.coursesByNumber.keys()) {
      const cycle = visit(courseNumber);
      if (cycle) {
        return cycle;
      }
    }

    return [];
  }

  clear(): void {
    this.coursesByNumber.clear();
    this.prerequisitesByCourse.clear();
    this.nextCoursesByCourse.clear();
  }

  normalizeNumber(value: string): string {
    return value.trim().toUpperCase().replace(/\s+/g, '');
  }

  private normalizeCourse(course: Course): Course {
    return {
      ...course,
      courseNumber: this.normalizeNumber(course.courseNumber),
      title: course.title.trim(),
      prerequisites: [
        ...new Set(
          course.prerequisites
            .map((value) => this.normalizeNumber(value))
            .filter(Boolean),
        ),
      ],
    };
  }

  private resolve(numbers?: Set<string>): Course[] {
    if (!numbers) {
      return [];
    }

    return [...numbers]
      .map((number) => this.coursesByNumber.get(number))
      .filter((course): course is Course => course !== undefined)
      .sort((a, b) => a.courseNumber.localeCompare(b.courseNumber));
  }
}
