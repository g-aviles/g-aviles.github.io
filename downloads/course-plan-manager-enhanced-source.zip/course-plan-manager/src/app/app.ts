import { DatePipe } from '@angular/common';
import {
  Component,
  computed,
  inject,
  signal,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CoursePlanStore } from './course-plan-store.service';
import { Course, ImportComparison } from './models';
import { SpreadsheetService } from './spreadsheet.service';

type View = 'overview' | 'courses' | 'import';

@Component({
  selector: 'app-root',
  imports: [DatePipe, FormsModule],
  templateUrl: './app.html',
  styleUrl: './app.scss',
})
export class App {
  protected readonly store = inject(CoursePlanStore);
  private readonly spreadsheet = inject(SpreadsheetService);

  protected readonly activeView = signal<View>('overview');
  protected readonly searchTerm = signal('');
  protected readonly searchError = signal('');
  protected readonly importComparison = signal<ImportComparison | null>(null);
  protected readonly importError = signal('');
  protected readonly importing = signal(false);
  protected readonly importApplied = signal(false);

  protected readonly visibleCourses = computed(() => {
    this.store.selectedPlan();
    const query = this.searchTerm().trim().toLowerCase();
    return this.store
      .getCourses()
      .filter(
        (course) =>
          !query ||
          course.courseNumber.toLowerCase().includes(query) ||
          course.title.toLowerCase().includes(query),
      );
  });

  protected readonly activeCourseCount = computed(
    () => this.store.selectedPlan()?.courses.filter((course) => course.active).length ?? 0,
  );

  protected readonly relationshipCount = computed(
    () =>
      this.store.selectedPlan()?.courses.reduce(
        (total, course) => total + course.prerequisites.length,
        0,
      ) ?? 0,
  );

  protected readonly importCounts = computed(() => {
    const changes = this.importComparison()?.changes ?? [];
    return {
      added: changes.filter((change) => change.status === 'Added').length,
      modified: changes.filter((change) => change.status === 'Modified').length,
      unchanged: changes.filter((change) => change.status === 'Unchanged').length,
      missing: changes.filter((change) => change.status === 'Missing').length,
      invalid: changes.filter((change) => change.status === 'Invalid').length,
    };
  });

  protected setView(view: View): void {
    this.activeView.set(view);
  }

  protected selectPlan(planId: string): void {
    this.store.selectPlan(planId);
    this.searchTerm.set('');
    this.searchError.set('');
  }

  protected searchCourse(): void {
    const value = this.searchTerm().trim();
    if (!value) {
      this.searchError.set('Enter a course number or choose a course below.');
      return;
    }

    const exact = this.store
      .getCourses()
      .find(
        (course) =>
          course.courseNumber.toLowerCase() === value.toLowerCase() ||
          course.title.toLowerCase() === value.toLowerCase(),
      );

    if (!exact || !this.store.selectCourse(exact.courseNumber)) {
      this.searchError.set('No exact match found. Choose a result from the course list.');
      return;
    }

    this.searchError.set('');
    this.activeView.set('overview');
  }

  protected selectCourse(course: Course): void {
    this.store.selectCourse(course.courseNumber);
    this.searchError.set('');
    this.activeView.set('overview');
  }

  protected async importFile(event: Event): Promise<void> {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;

    this.importing.set(true);
    this.importError.set('');
    this.importComparison.set(null);
    this.importApplied.set(false);

    try {
      const courses = await this.spreadsheet.read(file);
      if (!courses.length) {
        throw new Error('No course records were found.');
      }
      this.importComparison.set(
        this.store.compareImport(file.name, courses),
      );
    } catch (error) {
      this.importError.set(
        error instanceof Error
          ? error.message
          : 'The spreadsheet could not be read.',
      );
    } finally {
      this.importing.set(false);
      input.value = '';
    }
  }

  protected applyImport(): void {
    const comparison = this.importComparison();
    if (!comparison) return;
    this.store.applyImport(comparison);
    this.importApplied.set(true);
  }

  protected statusClass(status: string): string {
    return `status-${status.toLowerCase()}`;
  }
}
