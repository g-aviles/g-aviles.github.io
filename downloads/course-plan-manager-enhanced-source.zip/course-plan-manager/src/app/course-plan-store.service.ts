import { computed, effect, inject, Injectable, signal } from '@angular/core';
import { CourseIndexService } from './course-index.service';
import { INITIAL_PLANS } from './mock-data';
import {
  Course,
  CourseChange,
  CoursePlan,
  ImportComparison,
} from './models';

const STORAGE_KEY = 'cs-course-plan-manager.plans.v1';

@Injectable({ providedIn: 'root' })
export class CoursePlanStore {
  private readonly index = inject(CourseIndexService);
  private readonly plansState = signal<CoursePlan[]>(this.loadStoredPlans());
  private readonly selectedPlanIdState = signal(this.plansState()[0]?.id ?? '');
  private readonly selectedCourseNumberState = signal('CSCI300');

  readonly plans = this.plansState.asReadonly();
  readonly selectedPlanId = this.selectedPlanIdState.asReadonly();
  readonly selectedCourseNumber = this.selectedCourseNumberState.asReadonly();

  readonly selectedPlan = computed(
    () =>
      this.plansState().find(
        (plan) => plan.id === this.selectedPlanIdState(),
      ) ?? this.plansState()[0],
  );

  readonly selectedCourse = computed(() =>
    this.index.findCourse(this.selectedCourseNumberState()),
  );

  readonly prerequisites = computed(() =>
    this.index.getPrerequisites(this.selectedCourseNumberState()),
  );

  readonly nextCourses = computed(() =>
    this.index.getNextCourses(this.selectedCourseNumberState()),
  );

  constructor() {
    effect(() => {
      const plan = this.selectedPlan();
      this.index.load(plan?.courses ?? []);

      if (
        plan &&
        !this.index.findCourse(this.selectedCourseNumberState())
      ) {
        this.selectedCourseNumberState.set(
          this.index.getAllCourses()[0]?.courseNumber ?? '',
        );
      }
    });

    effect(() => {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.plansState()));
    });
  }

  getCourses(): Course[] {
    this.selectedPlan();
    return this.index.getAllCourses();
  }

  selectPlan(planId: string): void {
    this.selectedPlanIdState.set(planId);
  }

  selectCourse(courseNumber: string): boolean {
    const course = this.index.findCourse(courseNumber);
    if (!course) {
      return false;
    }
    this.selectedCourseNumberState.set(course.courseNumber);
    return true;
  }

  compareImport(fileName: string, importedCourses: Course[]): ImportComparison {
    const currentMap = new Map(
      this.getCourses().map((course) => [course.courseNumber, course]),
    );
    const incomingMap = new Map(
      importedCourses.map((course) => [course.courseNumber, course]),
    );
    const changes: CourseChange[] = [];

    for (const incoming of importedCourses) {
      const validationMessage = this.validateCourse(incoming, incomingMap);
      if (validationMessage) {
        changes.push({
          courseNumber: incoming.courseNumber || 'Unknown',
          status: 'Invalid',
          incoming,
          changedFields: [],
          message: validationMessage,
        });
        continue;
      }

      const previous = currentMap.get(incoming.courseNumber);
      if (!previous) {
        changes.push({
          courseNumber: incoming.courseNumber,
          status: 'Added',
          incoming,
          changedFields: [],
        });
        continue;
      }

      const changedFields = this.changedFields(previous, incoming);
      changes.push({
        courseNumber: incoming.courseNumber,
        status: changedFields.length ? 'Modified' : 'Unchanged',
        previous,
        incoming,
        changedFields,
      });
    }

    for (const previous of currentMap.values()) {
      if (!incomingMap.has(previous.courseNumber)) {
        changes.push({
          courseNumber: previous.courseNumber,
          status: 'Missing',
          previous,
          changedFields: [],
          message: 'This course is not present in the imported plan.',
        });
      }
    }

    const validationIndex = new CourseIndexService();
    validationIndex.load(importedCourses);
    const cyclePath = validationIndex.findCycle();

    return {
      fileName,
      importedCourses,
      changes: changes.sort((a, b) =>
        a.courseNumber.localeCompare(b.courseNumber),
      ),
      hasCycles: cyclePath.length > 0,
      cyclePath,
    };
  }

  applyImport(comparison: ImportComparison): void {
    if (comparison.hasCycles) {
      return;
    }

    const validIncoming = comparison.changes
      .filter(
        (change) =>
          change.status !== 'Invalid' &&
          change.status !== 'Missing' &&
          change.incoming,
      )
      .map((change) => ({ ...change.incoming!, active: true }));

    const missing = comparison.changes
      .filter((change) => change.status === 'Missing' && change.previous)
      .map((change) => ({ ...change.previous!, active: false }));

    const selectedId = this.selectedPlanIdState();
    this.plansState.update((plans) =>
      plans.map((plan) =>
        plan.id === selectedId
          ? {
              ...plan,
              version: plan.version + 1,
              updatedAt: new Date().toISOString(),
              courses: [...validIncoming, ...missing],
            }
          : plan,
      ),
    );
  }

  exportCsv(): void {
    const headers = ['Course Number', 'Course Title', 'Prerequisites', 'Credits', 'Status'];
    const rows = this.getCourses().map((course) => [
      course.courseNumber,
      course.title,
      course.prerequisites.join(';'),
      String(course.credits),
      course.active ? 'Active' : 'Inactive',
    ]);
    const csv = [headers, ...rows]
      .map((row) => row.map((value) => this.csvCell(value)).join(','))
      .join('\r\n');

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `${this.selectedPlan().title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')}-v${this.selectedPlan().version}.csv`;
    anchor.click();
    URL.revokeObjectURL(url);
  }

  resetDemo(): void {
    this.plansState.set(structuredClone(INITIAL_PLANS));
    this.selectedPlanIdState.set(INITIAL_PLANS[0].id);
    this.selectedCourseNumberState.set('CSCI300');
  }

  private validateCourse(
    course: Course,
    incomingMap: Map<string, Course>,
  ): string | undefined {
    if (!course.courseNumber || !course.title) {
      return 'Course number and title are required.';
    }
    if (course.prerequisites.includes(course.courseNumber)) {
      return 'A course cannot require itself.';
    }
    const missing = course.prerequisites.filter(
      (number) => !incomingMap.has(number),
    );
    return missing.length
      ? `Missing prerequisite record: ${missing.join(', ')}`
      : undefined;
  }

  private changedFields(previous: Course, incoming: Course): string[] {
    const changed: string[] = [];
    if (previous.title !== incoming.title) changed.push('Title');
    if (previous.credits !== incoming.credits) changed.push('Credits');
    if (
      [...previous.prerequisites].sort().join('|') !==
      [...incoming.prerequisites].sort().join('|')
    ) {
      changed.push('Prerequisites');
    }
    return changed;
  }

  private csvCell(value: string): string {
    return /[",\r\n]/.test(value) ? `"${value.replace(/"/g, '""')}"` : value;
  }

  private loadStoredPlans(): CoursePlan[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      return stored ? JSON.parse(stored) : structuredClone(INITIAL_PLANS);
    } catch {
      return structuredClone(INITIAL_PLANS);
    }
  }
}
