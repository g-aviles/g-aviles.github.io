import { CourseIndexService } from './course-index.service';
import { Course } from './models';

const courses: Course[] = [
  {
    courseNumber: 'CSCI100',
    title: 'Introduction',
    prerequisites: [],
    credits: 3,
    active: true,
  },
  {
    courseNumber: 'CSCI200',
    title: 'Data Structures',
    prerequisites: ['CSCI100'],
    credits: 3,
    active: true,
  },
  {
    courseNumber: 'CSCI300',
    title: 'Algorithms',
    prerequisites: ['CSCI200'],
    credits: 3,
    active: true,
  },
];

describe('CourseIndexService', () => {
  it('retrieves a normalized course from the hash map', () => {
    const service = new CourseIndexService();
    service.load(courses);
    expect(service.findCourse(' csci 200 ')?.title).toBe('Data Structures');
  });

  it('builds forward and reverse adjacency lists', () => {
    const service = new CourseIndexService();
    service.load(courses);
    expect(service.getPrerequisites('CSCI200')[0].courseNumber).toBe('CSCI100');
    expect(service.getNextCourses('CSCI200')[0].courseNumber).toBe('CSCI300');
  });

  it('detects a cycle with depth-first search', () => {
    const service = new CourseIndexService();
    service.load([
      { ...courses[0], prerequisites: ['CSCI300'] },
      courses[1],
      courses[2],
    ]);
    expect(service.findCycle()).toEqual([
      'CSCI100',
      'CSCI300',
      'CSCI200',
      'CSCI100',
    ]);
  });
});
