package com.eventplanner.timely;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

import org.junit.Test;

import java.time.LocalDateTime;
import java.time.ZoneId;

public class EventTest {
    @Test
    public void constructorTrimsAndPreservesValidEvent() {
        long start = millis(2026, 7, 19, 9);
        Event event = new Event(4, "USER@EXAMPLE.COM", " Planning ", start,
                start + 3_600_000L, "Meeting", " Notes ");

        assertEquals("user@example.com", event.getOwnerEmail());
        assertEquals("Planning", event.getTitle());
        assertEquals("Notes", event.getDescription());
        assertEquals(start, event.getStartMillis());
    }

    @Test
    public void constructorRejectsBlankTitle() {
        long start = millis(2026, 7, 19, 9);
        assertThrows(IllegalArgumentException.class,
                () -> new Event(1, "user@example.com", "  ", start,
                        start + 3_600_000L, "Meeting", ""));
    }

    @Test
    public void constructorRejectsEndBeforeStart() {
        long start = millis(2026, 7, 19, 9);
        assertThrows(IllegalArgumentException.class,
                () -> new Event(1, "user@example.com", "Meeting", start,
                        start, "Meeting", ""));
    }

    private long millis(int year, int month, int day, int hour) {
        return LocalDateTime.of(year, month, day, hour, 0)
                .atZone(ZoneId.systemDefault())
                .toInstant()
                .toEpochMilli();
    }
}
