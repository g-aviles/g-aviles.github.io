package com.eventplanner.timely;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class PasswordHasherTest {
    @Test
    public void hashUsesSaltAndVerifiesCorrectPassword() {
        String first = PasswordHasher.hash("correct horse battery staple");
        String second = PasswordHasher.hash("correct horse battery staple");

        assertNotEquals(first, second);
        assertTrue(PasswordHasher.verify("correct horse battery staple", first));
        assertFalse(PasswordHasher.verify("wrong password", first));
    }

    @Test
    public void verifyRejectsMalformedHash() {
        assertFalse(PasswordHasher.verify("password", "not-a-hash"));
    }
}
