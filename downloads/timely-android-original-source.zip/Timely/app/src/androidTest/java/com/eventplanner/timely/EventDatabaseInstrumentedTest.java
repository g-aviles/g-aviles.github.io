package com.eventplanner.timely;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import android.content.Context;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class EventDatabaseInstrumentedTest {
    private Context context;
    private EventDatabaseHelper database;

    @Before
    public void setUp() {
        context = InstrumentationRegistry.getInstrumentation().getTargetContext();
        context.deleteDatabase(EventDatabaseHelper.DATABASE_NAME);
        database = new EventDatabaseHelper(context);
    }

    @After
    public void tearDown() {
        database.close();
        context.deleteDatabase(EventDatabaseHelper.DATABASE_NAME);
    }

    @Test
    public void eventsAreOrderedAndIsolatedByOwner() {
        long later = 2_000_000L;
        long earlier = 1_000_000L;
        long firstId = database.insertEvent(
                "first@example.com", "Later", later, later + 1_000L, "Task", "");
        database.insertEvent(
                "first@example.com", "Earlier", earlier, earlier + 1_000L, "Task", "");
        database.insertEvent(
                "second@example.com", "Private", earlier, earlier + 1_000L, "Task", "");

        assertEquals(2, database.getAllEvents("first@example.com").size());
        assertEquals("Earlier", database.getAllEvents("first@example.com").get(0).getTitle());
        assertEquals(1, database.getAllEvents("second@example.com").size());
        assertNotNull(database.getEventById((int) firstId, "first@example.com"));
        assertTrue(database.deleteEvent((int) firstId, "first@example.com"));
    }
}
