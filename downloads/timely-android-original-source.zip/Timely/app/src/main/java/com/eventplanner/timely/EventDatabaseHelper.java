package com.eventplanner.timely;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/** Persists account-owned events using canonical epoch-millisecond timestamps. */
public class EventDatabaseHelper extends SQLiteOpenHelper {
    private static final String TAG = "EventDatabaseHelper";

    public static final String DATABASE_NAME = "events.db";
    public static final int DATABASE_VERSION = 2;
    public static final String TABLE_NAME = "events";

    public static final String COL_ID = "id";
    public static final String COL_OWNER = "owner_email";
    public static final String COL_TITLE = "title";
    public static final String COL_DATE = "date";
    public static final String COL_START = "start_time";
    public static final String COL_END = "end_time";
    public static final String COL_START_MILLIS = "start_millis";
    public static final String COL_END_MILLIS = "end_millis";
    public static final String COL_TYPE = "type";
    public static final String COL_DESCRIPTION = "description";

    private static final String[] EVENT_PROJECTION = {
            COL_ID, COL_OWNER, COL_TITLE, COL_START_MILLIS, COL_END_MILLIS, COL_TYPE, COL_DESCRIPTION
    };

    public EventDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        database.execSQL("CREATE TABLE " + TABLE_NAME + " ("
                + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_OWNER + " TEXT NOT NULL, "
                + COL_TITLE + " TEXT NOT NULL, "
                + COL_DATE + " TEXT NOT NULL, "
                + COL_START + " TEXT NOT NULL, "
                + COL_END + " TEXT NOT NULL, "
                + COL_START_MILLIS + " INTEGER NOT NULL, "
                + COL_END_MILLIS + " INTEGER NOT NULL, "
                + COL_TYPE + " TEXT NOT NULL, "
                + COL_DESCRIPTION + " TEXT NOT NULL DEFAULT '')");
        createIndexes(database);
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            database.beginTransaction();
            try {
                database.execSQL("ALTER TABLE " + TABLE_NAME + " ADD COLUMN " + COL_OWNER
                        + " TEXT NOT NULL DEFAULT ''");
                database.execSQL("ALTER TABLE " + TABLE_NAME + " ADD COLUMN " + COL_START_MILLIS
                        + " INTEGER NOT NULL DEFAULT 0");
                database.execSQL("ALTER TABLE " + TABLE_NAME + " ADD COLUMN " + COL_END_MILLIS
                        + " INTEGER NOT NULL DEFAULT 0");
                migrateLegacyTimestamps(database);
                createIndexes(database);
                database.setTransactionSuccessful();
            } finally {
                database.endTransaction();
            }
        }
    }

    public void claimUnownedEvents(String ownerEmail) {
        String owner = SessionManager.normalizeEmail(ownerEmail);
        if (owner.isEmpty()) {
            return;
        }
        ContentValues values = new ContentValues();
        values.put(COL_OWNER, owner);
        getWritableDatabase().update(TABLE_NAME, values, COL_OWNER + "=''", null);
    }

    public long insertEvent(String ownerEmail, String title, long startMillis,
                            long endMillis, String type, String description) {
        if (!isValid(ownerEmail, title, startMillis, endMillis, type)) {
            return -1;
        }
        try {
            return getWritableDatabase().insert(TABLE_NAME, null,
                    toValues(ownerEmail, title, startMillis, endMillis, type, description));
        } catch (SQLiteException exception) {
            Log.e(TAG, "Unable to insert event", exception);
            return -1;
        }
    }

    public ArrayList<Event> getAllEvents(String ownerEmail) {
        ArrayList<Event> events = new ArrayList<>();
        String owner = SessionManager.normalizeEmail(ownerEmail);
        if (owner.isEmpty()) {
            return events;
        }
        try (Cursor cursor = getReadableDatabase().query(
                TABLE_NAME,
                EVENT_PROJECTION,
                COL_OWNER + "=?",
                new String[]{owner},
                null,
                null,
                COL_START_MILLIS + " ASC")) {
            while (cursor.moveToNext()) {
                Event event = fromCursor(cursor);
                if (event != null) {
                    events.add(event);
                }
            }
        } catch (SQLiteException | IllegalArgumentException exception) {
            Log.e(TAG, "Unable to read events", exception);
        }
        return events;
    }

    public boolean deleteEvent(int id, String ownerEmail) {
        try {
            return getWritableDatabase().delete(
                    TABLE_NAME,
                    COL_ID + "=? AND " + COL_OWNER + "=?",
                    new String[]{String.valueOf(id), SessionManager.normalizeEmail(ownerEmail)}) > 0;
        } catch (SQLiteException exception) {
            Log.e(TAG, "Unable to delete event", exception);
            return false;
        }
    }

    public boolean updateEvent(int id, String ownerEmail, String title, long startMillis,
                               long endMillis, String type, String description) {
        if (!isValid(ownerEmail, title, startMillis, endMillis, type)) {
            return false;
        }
        try {
            return getWritableDatabase().update(
                    TABLE_NAME,
                    toValues(ownerEmail, title, startMillis, endMillis, type, description),
                    COL_ID + "=? AND " + COL_OWNER + "=?",
                    new String[]{String.valueOf(id), SessionManager.normalizeEmail(ownerEmail)}) > 0;
        } catch (SQLiteException exception) {
            Log.e(TAG, "Unable to update event", exception);
            return false;
        }
    }

    public Event getEventById(int id, String ownerEmail) {
        try (Cursor cursor = getReadableDatabase().query(
                TABLE_NAME,
                EVENT_PROJECTION,
                COL_ID + "=? AND " + COL_OWNER + "=?",
                new String[]{String.valueOf(id), SessionManager.normalizeEmail(ownerEmail)},
                null,
                null,
                null,
                "1")) {
            return cursor.moveToFirst() ? fromCursor(cursor) : null;
        } catch (SQLiteException | IllegalArgumentException exception) {
            Log.e(TAG, "Unable to read event", exception);
            return null;
        }
    }

    private ContentValues toValues(String ownerEmail, String title, long startMillis,
                                   long endMillis, String type, String description) {
        Event event = new Event(-1, ownerEmail, title, startMillis, endMillis, type, description);
        ContentValues values = new ContentValues();
        values.put(COL_OWNER, event.getOwnerEmail());
        values.put(COL_TITLE, event.getTitle());
        values.put(COL_DATE, event.getDate());
        values.put(COL_START, event.getStartTime());
        values.put(COL_END, event.getEndTime());
        values.put(COL_START_MILLIS, event.getStartMillis());
        values.put(COL_END_MILLIS, event.getEndMillis());
        values.put(COL_TYPE, event.getType());
        values.put(COL_DESCRIPTION, event.getDescription());
        return values;
    }

    private Event fromCursor(Cursor cursor) {
        return new Event(
                cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID)),
                cursor.getString(cursor.getColumnIndexOrThrow(COL_OWNER)),
                cursor.getString(cursor.getColumnIndexOrThrow(COL_TITLE)),
                cursor.getLong(cursor.getColumnIndexOrThrow(COL_START_MILLIS)),
                cursor.getLong(cursor.getColumnIndexOrThrow(COL_END_MILLIS)),
                cursor.getString(cursor.getColumnIndexOrThrow(COL_TYPE)),
                cursor.getString(cursor.getColumnIndexOrThrow(COL_DESCRIPTION)));
    }

    private boolean isValid(String ownerEmail, String title, long startMillis,
                            long endMillis, String type) {
        return !SessionManager.normalizeEmail(ownerEmail).isEmpty()
                && title != null
                && !title.trim().isEmpty()
                && type != null
                && !type.trim().isEmpty()
                && endMillis > startMillis;
    }

    private void createIndexes(SQLiteDatabase database) {
        database.execSQL("CREATE INDEX IF NOT EXISTS index_events_owner_start ON "
                + TABLE_NAME + "(" + COL_OWNER + ", " + COL_START_MILLIS + ")");
    }

    private void migrateLegacyTimestamps(SQLiteDatabase database) {
        SimpleDateFormat parser = new SimpleDateFormat("M/d/yyyy h a", Locale.US);
        parser.setLenient(false);
        String[] projection = {COL_ID, COL_DATE, COL_START, COL_END};
        try (Cursor cursor = database.query(TABLE_NAME, projection, null, null, null, null, null)) {
            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(COL_DATE));
                String start = cursor.getString(cursor.getColumnIndexOrThrow(COL_START));
                String end = cursor.getString(cursor.getColumnIndexOrThrow(COL_END));
                try {
                    Date parsedStart = parser.parse(date + " " + start);
                    Date parsedEnd = parser.parse(date + " " + end);
                    if (parsedStart == null || parsedEnd == null) {
                        continue;
                    }
                    long startMillis = parsedStart.getTime();
                    long endMillis = parsedEnd.getTime();
                    if (endMillis <= startMillis) {
                        endMillis += 24L * 60L * 60L * 1000L;
                    }
                    ContentValues values = new ContentValues();
                    values.put(COL_START_MILLIS, startMillis);
                    values.put(COL_END_MILLIS, endMillis);
                    database.update(TABLE_NAME, values, COL_ID + "=?", new String[]{String.valueOf(id)});
                } catch (ParseException exception) {
                    Log.w(TAG, "Skipping invalid legacy event " + id, exception);
                }
            }
        }
    }
}
