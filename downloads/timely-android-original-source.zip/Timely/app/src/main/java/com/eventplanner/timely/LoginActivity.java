package com.eventplanner.timely;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/** Authenticates an existing local account or creates a securely stored account. */
public class LoginActivity extends AppCompatActivity {
    private static final int MIN_PASSWORD_LENGTH = 8;

    private EditText emailInput;
    private EditText passwordInput;
    private AccDatabaseHelper database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        database = new AccDatabaseHelper(this);
        initializeViews();
    }

    private void initializeViews() {
        emailInput = findViewById(R.id.etUsername);
        passwordInput = findViewById(R.id.etPassword);
        Button loginButton = findViewById(R.id.btnLogin);
        TextView createAccount = findViewById(R.id.tvCreateAccount);
        loginButton.setOnClickListener(view -> handleLogin());
        createAccount.setOnClickListener(view -> handleCreateAccount());
    }

    private void handleLogin() {
        String email = normalizedEmail();
        String password = passwordInput.getText().toString();
        if (!isValidEmail(email) || password.isEmpty()) {
            Toast.makeText(this, R.string.enter_valid_credentials, Toast.LENGTH_SHORT).show();
            return;
        }
        if (!database.checkUser(email, password)) {
            Toast.makeText(this, R.string.invalid_credentials, Toast.LENGTH_SHORT).show();
            return;
        }
        SessionManager.signIn(this, email);
        Toast.makeText(this, R.string.login_successful, Toast.LENGTH_SHORT).show();
        startActivity(new Intent(this, EventListActivity.class));
        finish();
    }

    private void handleCreateAccount() {
        String email = normalizedEmail();
        String password = passwordInput.getText().toString();
        if (!isValidEmail(email)) {
            Toast.makeText(this, R.string.enter_valid_email, Toast.LENGTH_SHORT).show();
            return;
        }
        if (password.length() < MIN_PASSWORD_LENGTH) {
            Toast.makeText(this, R.string.password_length_requirement, Toast.LENGTH_SHORT).show();
            return;
        }
        if (database.emailExists(email)) {
            Toast.makeText(this, R.string.user_already_exists, Toast.LENGTH_SHORT).show();
            return;
        }
        if (!database.insertUser(email, password)) {
            Toast.makeText(this, R.string.account_creation_failed, Toast.LENGTH_SHORT).show();
            return;
        }
        Toast.makeText(this, R.string.account_created, Toast.LENGTH_SHORT).show();
        emailInput.setText("");
        passwordInput.setText("");
    }

    private String normalizedEmail() {
        return SessionManager.normalizeEmail(emailInput.getText().toString());
    }

    private boolean isValidEmail(String email) {
        return !email.isEmpty() && Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    @Override
    protected void onDestroy() {
        if (database != null) {
            database.close();
        }
        super.onDestroy();
    }
}
