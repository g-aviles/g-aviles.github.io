package com.eventplanner.timely;

/** Shared keys used across activities, preferences, alarms, and receivers. */
public final class AppConstants {
    public static final String EXTRA_EVENT_ID = "com.eventplanner.timely.extra.EVENT_ID";
    public static final String EXTRA_OWNER_EMAIL = "com.eventplanner.timely.extra.OWNER_EMAIL";

    public static final String SETTINGS_PREFS = "settings_pref";
    public static final String KEY_NOTIFICATIONS_ENABLED = "notifications_enabled";
    public static final String KEY_SMS_ENABLED = "sms_enabled";
    public static final String KEY_PHONE_NUMBER = "phone_number";

    public static final String REMINDER_CHANNEL_ID = "event_reminders";
    public static final String ACTION_SMS_SENT = "com.eventplanner.timely.action.SMS_SENT";
    public static final String ACTION_SMS_DELIVERED = "com.eventplanner.timely.action.SMS_DELIVERED";

    private AppConstants() {
    }
}
