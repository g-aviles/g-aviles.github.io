package com.eventplanner.timely;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.PhoneNumberUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.ContextCompat;

/** Manages system-notification and SMS reminder settings independently. */
public class SettingsActivity extends AppCompatActivity {
    private SwitchCompat notificationSwitch;
    private SwitchCompat smsSwitch;
    private TextView notificationStatus;
    private TextView smsStatus;
    private EditText phoneInput;
    private SharedPreferences preferences;
    private boolean suppressSwitchCallbacks;

    private final ActivityResultLauncher<String> notificationPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                setNotificationEnabled(Boolean.TRUE.equals(granted));
                if (!granted) {
                    Toast.makeText(this, R.string.notification_permission_required, Toast.LENGTH_LONG).show();
                }
            });

    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                setSmsEnabled(Boolean.TRUE.equals(granted));
                if (!granted) {
                    Toast.makeText(this, R.string.sms_permission_required, Toast.LENGTH_LONG).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        preferences = getSharedPreferences(AppConstants.SETTINGS_PREFS, MODE_PRIVATE);
        initializeViews();
        loadPreferences();
        setupListeners();
    }

    private void initializeViews() {
        notificationSwitch = findViewById(R.id.switchNotifications);
        smsSwitch = findViewById(R.id.switchSms);
        notificationStatus = findViewById(R.id.tvNotificationStatus);
        smsStatus = findViewById(R.id.tvSmsStatus);
        phoneInput = findViewById(R.id.etPhoneNumber);
    }

    private void loadPreferences() {
        boolean notificationsEnabled = preferences.getBoolean(
                AppConstants.KEY_NOTIFICATIONS_ENABLED, false) && hasNotificationPermission();
        boolean legacyReminderEnabled = preferences.getBoolean(
                AppConstants.KEY_NOTIFICATIONS_ENABLED, false);
        boolean smsEnabled = preferences.contains(AppConstants.KEY_SMS_ENABLED)
                ? preferences.getBoolean(AppConstants.KEY_SMS_ENABLED, false)
                : legacyReminderEnabled && hasSmsPermission();
        suppressSwitchCallbacks = true;
        notificationSwitch.setChecked(notificationsEnabled);
        smsSwitch.setChecked(smsEnabled && hasSmsPermission());
        suppressSwitchCallbacks = false;
        phoneInput.setText(preferences.getString(AppConstants.KEY_PHONE_NUMBER, ""));
        persistStates(notificationSwitch.isChecked(), smsSwitch.isChecked());
        updateStatusText();
    }

    private void setupListeners() {
        notificationSwitch.setOnCheckedChangeListener((button, checked) -> {
            if (suppressSwitchCallbacks) {
                return;
            }
            if (checked && !hasNotificationPermission()) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
            } else {
                setNotificationEnabled(checked);
            }
        });
        smsSwitch.setOnCheckedChangeListener((button, checked) -> {
            if (suppressSwitchCallbacks) {
                return;
            }
            if (checked && !hasSmsPermission()) {
                smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
            } else {
                setSmsEnabled(checked);
            }
        });

        Button save = findViewById(R.id.btnSaveSettings);
        save.setOnClickListener(view -> saveSettings());
        Button back = findViewById(R.id.btnBack);
        back.setOnClickListener(view -> finish());
    }

    private void saveSettings() {
        String normalizedPhone = PhoneNumberUtils.normalizeNumber(
                phoneInput.getText().toString().trim());
        if (smsSwitch.isChecked() && !PhoneNumberUtils.isGlobalPhoneNumber(normalizedPhone)) {
            phoneInput.setError(getString(R.string.valid_phone_required));
            return;
        }
        preferences.edit()
                .putString(AppConstants.KEY_PHONE_NUMBER, normalizedPhone)
                .putBoolean(AppConstants.KEY_NOTIFICATIONS_ENABLED, notificationSwitch.isChecked())
                .putBoolean(AppConstants.KEY_SMS_ENABLED, smsSwitch.isChecked())
                .apply();
        Toast.makeText(this, R.string.settings_saved, Toast.LENGTH_SHORT).show();
        finish();
    }

    private void setNotificationEnabled(boolean enabled) {
        suppressSwitchCallbacks = true;
        notificationSwitch.setChecked(enabled && hasNotificationPermission());
        suppressSwitchCallbacks = false;
        preferences.edit().putBoolean(
                AppConstants.KEY_NOTIFICATIONS_ENABLED, notificationSwitch.isChecked()).apply();
        updateStatusText();
    }

    private void setSmsEnabled(boolean enabled) {
        suppressSwitchCallbacks = true;
        smsSwitch.setChecked(enabled && hasSmsPermission());
        suppressSwitchCallbacks = false;
        preferences.edit().putBoolean(AppConstants.KEY_SMS_ENABLED, smsSwitch.isChecked()).apply();
        updateStatusText();
    }

    private void persistStates(boolean notificationsEnabled, boolean smsEnabled) {
        preferences.edit()
                .putBoolean(AppConstants.KEY_NOTIFICATIONS_ENABLED, notificationsEnabled)
                .putBoolean(AppConstants.KEY_SMS_ENABLED, smsEnabled)
                .apply();
    }

    private void updateStatusText() {
        notificationStatus.setText(notificationSwitch.isChecked()
                ? R.string.notifications_on
                : R.string.notifications_off);
        smsStatus.setText(smsSwitch.isChecked() ? R.string.sms_on : R.string.sms_off);
    }

    private boolean hasNotificationPermission() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU
                || ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }
}
