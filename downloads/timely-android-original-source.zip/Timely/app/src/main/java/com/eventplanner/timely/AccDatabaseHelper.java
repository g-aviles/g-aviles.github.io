package com.eventplanner.timely;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/** Persists local accounts and transparently upgrades legacy plain-text passwords. */
public class AccDatabaseHelper extends SQLiteOpenHelper {
    private static final String TAG = "AccDatabaseHelper";

    public static final String DATABASE_NAME = "account.db";
    public static final String TABLE_NAME = "user";
    public static final String COL_EMAIL = "email";
    public static final String COL_PASSWORD_HASH = "password";
    public static final int DATABASE_VERSION = 2;

    public AccDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        database.execSQL("CREATE TABLE " + TABLE_NAME + " ("
                + COL_EMAIL + " TEXT PRIMARY KEY, "
                + COL_PASSWORD_HASH + " TEXT NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion) {
        // Version 2 changes password contents from plain text to hashes without changing the schema.
        // Legacy rows are upgraded after the user proves the old password during login.
    }

    public boolean insertUser(String email, String password) {
        String normalizedEmail = SessionManager.normalizeEmail(email);
        if (normalizedEmail.isEmpty() || password == null || password.isEmpty()) {
            return false;
        }

        ContentValues values = new ContentValues();
        values.put(COL_EMAIL, normalizedEmail);
        values.put(COL_PASSWORD_HASH, PasswordHasher.hash(password));
        try {
            return getWritableDatabase().insert(TABLE_NAME, null, values) != -1;
        } catch (SQLiteException exception) {
            Log.e(TAG, "Unable to insert account", exception);
            return false;
        }
    }

    public boolean checkUser(String email, String password) {
        String normalizedEmail = SessionManager.normalizeEmail(email);
        if (normalizedEmail.isEmpty() || password == null) {
            return false;
        }

        try (Cursor cursor = getReadableDatabase().query(
                TABLE_NAME,
                new String[]{COL_PASSWORD_HASH},
                COL_EMAIL + "=?",
                new String[]{normalizedEmail},
                null,
                null,
                null,
                "1")) {
            if (!cursor.moveToFirst()) {
                return false;
            }
            String storedValue = cursor.getString(cursor.getColumnIndexOrThrow(COL_PASSWORD_HASH));
            if (PasswordHasher.isHash(storedValue)) {
                return PasswordHasher.verify(password, storedValue);
            }
            if (!storedValue.equals(password)) {
                return false;
            }
            upgradeLegacyPassword(normalizedEmail, password);
            return true;
        } catch (SQLiteException exception) {
            Log.e(TAG, "Unable to verify account", exception);
            return false;
        }
    }

    public boolean emailExists(String email) {
        String normalizedEmail = SessionManager.normalizeEmail(email);
        if (normalizedEmail.isEmpty()) {
            return false;
        }
        try (Cursor cursor = getReadableDatabase().query(
                TABLE_NAME,
                new String[]{COL_EMAIL},
                COL_EMAIL + "=?",
                new String[]{normalizedEmail},
                null,
                null,
                null,
                "1")) {
            return cursor.moveToFirst();
        } catch (SQLiteException exception) {
            Log.e(TAG, "Unable to query account", exception);
            return false;
        }
    }

    private void upgradeLegacyPassword(String email, String password) {
        ContentValues values = new ContentValues();
        values.put(COL_PASSWORD_HASH, PasswordHasher.hash(password));
        try {
            getWritableDatabase().update(TABLE_NAME, values, COL_EMAIL + "=?", new String[]{email});
        } catch (SQLiteException exception) {
            Log.e(TAG, "Unable to upgrade legacy password", exception);
        }
    }
}
