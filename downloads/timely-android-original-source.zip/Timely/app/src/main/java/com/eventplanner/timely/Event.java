package com.eventplanner.timely;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/**
 * Immutable calendar event whose start and end are stored as epoch milliseconds.
 * The end timestamp must be later than the start timestamp.
 */
public final class Event {
    private static final DateTimeFormatter DATE_FORMAT =
            DateTimeFormatter.ofPattern("M/d/uuuu", Locale.getDefault());
    private static final DateTimeFormatter TIME_FORMAT =
            DateTimeFormatter.ofPattern("h a", Locale.getDefault());

    private final int id;
    private final String ownerEmail;
    private final String title;
    private final long startMillis;
    private final long endMillis;
    private final String type;
    private final String description;

    public Event(int id, String ownerEmail, String title, long startMillis,
                 long endMillis, String type, String description) {
        if (title == null || title.trim().isEmpty()) {
            throw new IllegalArgumentException("Event title is required");
        }
        if (endMillis <= startMillis) {
            throw new IllegalArgumentException("Event end must be after its start");
        }
        this.id = id;
        this.ownerEmail = SessionManager.normalizeEmail(ownerEmail);
        this.title = title.trim();
        this.startMillis = startMillis;
        this.endMillis = endMillis;
        this.type = type == null ? "" : type;
        this.description = description == null ? "" : description.trim();
    }

    public int getId() {
        return id;
    }

    public String getOwnerEmail() {
        return ownerEmail;
    }

    public String getTitle() {
        return title;
    }

    public long getStartMillis() {
        return startMillis;
    }

    public long getEndMillis() {
        return endMillis;
    }

    public String getDate() {
        return DATE_FORMAT.format(getStartDate());
    }

    public String getStartTime() {
        return TIME_FORMAT.format(Instant.ofEpochMilli(startMillis).atZone(ZoneId.systemDefault()));
    }

    public String getEndTime() {
        return TIME_FORMAT.format(Instant.ofEpochMilli(endMillis).atZone(ZoneId.systemDefault()));
    }

    public LocalDate getStartDate() {
        return Instant.ofEpochMilli(startMillis).atZone(ZoneId.systemDefault()).toLocalDate();
    }

    public int getStartHour() {
        return Instant.ofEpochMilli(startMillis).atZone(ZoneId.systemDefault()).getHour();
    }

    public String getType() {
        return type;
    }

    public String getDescription() {
        return description;
    }
}
