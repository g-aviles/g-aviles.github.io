package com.eventplanner.timely;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.util.Arrays;
import java.util.Locale;

/** Creates and edits account-owned events and keeps their reminder alarm synchronized. */
public class EventActivity extends AppCompatActivity {
    private static final int NEW_EVENT_ID = -1;
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter
            .ofPattern("M/d/uuuu", Locale.getDefault())
            .withResolverStyle(ResolverStyle.STRICT);

    private EditText eventTitle;
    private EditText eventDate;
    private EditText description;
    private Spinner startHour;
    private Spinner startAmPm;
    private Spinner endHour;
    private Spinner endAmPm;
    private Spinner eventType;
    private Button saveButton;

    private EventDatabaseHelper database;
    private String ownerEmail;
    private int eventId = NEW_EVENT_ID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ownerEmail = SessionManager.getAuthenticatedEmail(this);
        if (ownerEmail.isEmpty()) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }
        setContentView(R.layout.activity_event);
        database = new EventDatabaseHelper(this);
        initializeViews();
        setupSpinners();
        loadEventForEditing();
        setupDatePicker();
        setupButtonListeners();
    }

    private void initializeViews() {
        eventTitle = findViewById(R.id.etEventTitle);
        eventDate = findViewById(R.id.etEventDate);
        description = findViewById(R.id.etDescription);
        startHour = findViewById(R.id.spinnerStartHour);
        startAmPm = findViewById(R.id.spinnerStartAmPm);
        endHour = findViewById(R.id.spinnerEndHour);
        endAmPm = findViewById(R.id.spinnerEndAmPm);
        eventType = findViewById(R.id.spinnerEventType);
        saveButton = findViewById(R.id.btnSaveEvent);
    }

    private void setupSpinners() {
        ArrayAdapter<CharSequence> hourAdapter = ArrayAdapter.createFromResource(
                this, R.array.event_hours, android.R.layout.simple_spinner_dropdown_item);
        ArrayAdapter<CharSequence> amPmAdapter = ArrayAdapter.createFromResource(
                this, R.array.am_pm, android.R.layout.simple_spinner_dropdown_item);
        ArrayAdapter<CharSequence> typeAdapter = ArrayAdapter.createFromResource(
                this, R.array.event_types, android.R.layout.simple_spinner_dropdown_item);
        startHour.setAdapter(hourAdapter);
        endHour.setAdapter(hourAdapter);
        startAmPm.setAdapter(amPmAdapter);
        endAmPm.setAdapter(amPmAdapter);
        eventType.setAdapter(typeAdapter);
    }

    private void loadEventForEditing() {
        eventId = getIntent().getIntExtra(AppConstants.EXTRA_EVENT_ID, NEW_EVENT_ID);
        if (eventId == NEW_EVENT_ID) {
            return;
        }
        Event event = database.getEventById(eventId, ownerEmail);
        if (event == null) {
            Toast.makeText(this, R.string.event_not_found, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        eventTitle.setText(event.getTitle());
        eventDate.setText(event.getDate());
        description.setText(event.getDescription());
        setSpinnerValue(startHour, event.getStartTime().split(" ")[0]);
        setSpinnerValue(startAmPm, event.getStartTime().split(" ")[1]);
        setSpinnerValue(endHour, event.getEndTime().split(" ")[0]);
        setSpinnerValue(endAmPm, event.getEndTime().split(" ")[1]);
        setSpinnerValue(eventType, event.getType());
        saveButton.setText(R.string.update_event_button);
    }

    private void setupDatePicker() {
        eventDate.setOnClickListener(view -> {
            LocalDate initialDate = parseDateOrToday(eventDate.getText().toString());
            DatePickerDialog dialog = new DatePickerDialog(
                    this,
                    (picker, year, month, day) -> eventDate.setText(
                            DATE_FORMAT.format(LocalDate.of(year, month + 1, day))),
                    initialDate.getYear(),
                    initialDate.getMonthValue() - 1,
                    initialDate.getDayOfMonth());
            dialog.show();
        });
    }

    private void setupButtonListeners() {
        saveButton.setOnClickListener(view -> handleSave());
        Button cancelButton = findViewById(R.id.btnCancel);
        cancelButton.setOnClickListener(view -> {
            setResult(RESULT_CANCELED);
            finish();
        });
    }

    private void handleSave() {
        String title = eventTitle.getText().toString().trim();
        String dateText = eventDate.getText().toString().trim();
        String type = String.valueOf(eventType.getSelectedItem());
        String eventDescription = description.getText().toString().trim();

        if (title.isEmpty() || dateText.isEmpty()) {
            Toast.makeText(this, R.string.fill_required_fields, Toast.LENGTH_SHORT).show();
            return;
        }

        long startMillis;
        long endMillis;
        try {
            LocalDate date = LocalDate.parse(dateText, DATE_FORMAT);
            startMillis = toMillis(date, startHour, startAmPm);
            endMillis = toMillis(date, endHour, endAmPm);
        } catch (DateTimeException | NumberFormatException exception) {
            Toast.makeText(this, R.string.invalid_event_date, Toast.LENGTH_SHORT).show();
            return;
        }
        if (endMillis <= startMillis) {
            Toast.makeText(this, R.string.end_time_after_start, Toast.LENGTH_SHORT).show();
            return;
        }

        boolean saved;
        if (eventId == NEW_EVENT_ID) {
            long insertedId = database.insertEvent(
                    ownerEmail, title, startMillis, endMillis, type, eventDescription);
            saved = insertedId != -1;
            if (saved) {
                eventId = (int) insertedId;
            }
        } else {
            saved = database.updateEvent(
                    eventId, ownerEmail, title, startMillis, endMillis, type, eventDescription);
        }
        if (!saved) {
            Toast.makeText(this, R.string.event_save_failed, Toast.LENGTH_SHORT).show();
            return;
        }

        Event savedEvent = new Event(
                eventId, ownerEmail, title, startMillis, endMillis, type, eventDescription);
        ReminderScheduler.cancel(this, eventId, ownerEmail);
        SharedPreferences preferences = getSharedPreferences(
                AppConstants.SETTINGS_PREFS, MODE_PRIVATE);
        boolean remindersEnabled = preferences.getBoolean(
                AppConstants.KEY_NOTIFICATIONS_ENABLED, false)
                || preferences.getBoolean(AppConstants.KEY_SMS_ENABLED, false);
        if (remindersEnabled && !ReminderScheduler.schedule(this, savedEvent)
                && startMillis > System.currentTimeMillis()) {
            Toast.makeText(this, R.string.reminder_schedule_failed, Toast.LENGTH_LONG).show();
        }

        Toast.makeText(
                this,
                getIntent().hasExtra(AppConstants.EXTRA_EVENT_ID)
                        ? R.string.event_updated
                        : R.string.event_saved,
                Toast.LENGTH_SHORT).show();
        setResult(RESULT_OK);
        finish();
    }

    private long toMillis(LocalDate date, Spinner hourSpinner, Spinner amPmSpinner) {
        int hour = Integer.parseInt(String.valueOf(hourSpinner.getSelectedItem()));
        String period = String.valueOf(amPmSpinner.getSelectedItem());
        int hour24 = hour % 12 + ("PM".equals(period) ? 12 : 0);
        return LocalDateTime.of(date, java.time.LocalTime.of(hour24, 0))
                .atZone(ZoneId.systemDefault())
                .toInstant()
                .toEpochMilli();
    }

    private LocalDate parseDateOrToday(String value) {
        try {
            return LocalDate.parse(value.trim(), DATE_FORMAT);
        } catch (DateTimeException exception) {
            return LocalDate.now();
        }
    }

    private void setSpinnerValue(Spinner spinner, String value) {
        ArrayAdapter<?> adapter = (ArrayAdapter<?>) spinner.getAdapter();
        for (int index = 0; index < adapter.getCount(); index++) {
            if (String.valueOf(adapter.getItem(index)).equals(value)) {
                spinner.setSelection(index);
                return;
            }
        }
    }

    @Override
    protected void onDestroy() {
        if (database != null) {
            database.close();
        }
        super.onDestroy();
    }
}
