package com.eventplanner.timely;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.telephony.PhoneNumberUtils;
import android.telephony.SmsManager;
import android.util.Log;

import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

/** Delivers a persisted event as a system notification and/or SMS reminder. */
public class ReminderReceiver extends BroadcastReceiver {
    private static final String TAG = "ReminderReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        int eventId = intent.getIntExtra(AppConstants.EXTRA_EVENT_ID, -1);
        String ownerEmail = intent.getStringExtra(AppConstants.EXTRA_OWNER_EMAIL);
        if (eventId < 0 || ownerEmail == null || ownerEmail.trim().isEmpty()) {
            Log.w(TAG, "Ignoring reminder with incomplete event identity");
            return;
        }

        EventDatabaseHelper database = new EventDatabaseHelper(context);
        Event event = database.getEventById(eventId, ownerEmail);
        database.close();
        if (event == null) {
            Log.i(TAG, "Ignoring reminder for a missing or deleted event");
            return;
        }

        SharedPreferences preferences = context.getSharedPreferences(
                AppConstants.SETTINGS_PREFS, Context.MODE_PRIVATE);
        if (preferences.getBoolean(AppConstants.KEY_NOTIFICATIONS_ENABLED, false)) {
            showNotification(context, event);
        }
        if (preferences.getBoolean(AppConstants.KEY_SMS_ENABLED, false)) {
            sendSms(context, event, preferences.getString(AppConstants.KEY_PHONE_NUMBER, ""));
        }
    }

    private void showNotification(Context context, Event event) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            Log.w(TAG, "Notification permission is unavailable");
            return;
        }

        NotificationManager manager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) {
            Log.e(TAG, "Notification service is unavailable");
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(new NotificationChannel(
                    AppConstants.REMINDER_CHANNEL_ID,
                    context.getString(R.string.event_reminders_channel),
                    NotificationManager.IMPORTANCE_HIGH));
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(
                context, AppConstants.REMINDER_CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(context.getString(R.string.event_reminder_title, event.getTitle()))
                .setContentText(event.getDescription())
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true);
        manager.notify(event.getId(), builder.build());
    }

    private void sendSms(Context context, Event event, String rawPhoneNumber) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            Log.w(TAG, "SMS permission is unavailable");
            return;
        }
        String phoneNumber = PhoneNumberUtils.normalizeNumber(rawPhoneNumber);
        if (!PhoneNumberUtils.isGlobalPhoneNumber(phoneNumber)) {
            Log.w(TAG, "Configured SMS number is invalid");
            return;
        }

        Intent sentIntent = new Intent(context, SmsStatusReceiver.class)
                .setAction(AppConstants.ACTION_SMS_SENT)
                .putExtra(AppConstants.EXTRA_EVENT_ID, event.getId());
        Intent deliveredIntent = new Intent(context, SmsStatusReceiver.class)
                .setAction(AppConstants.ACTION_SMS_DELIVERED)
                .putExtra(AppConstants.EXTRA_EVENT_ID, event.getId());
        PendingIntent sent = PendingIntent.getBroadcast(
                context,
                event.getId() * 2,
                sentIntent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent delivered = PendingIntent.getBroadcast(
                context,
                event.getId() * 2 + 1,
                deliveredIntent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        try {
            SmsManager.getDefault().sendTextMessage(
                    phoneNumber,
                    null,
                    context.getString(R.string.sms_reminder_message, event.getTitle(), event.getDescription()),
                    sent,
                    delivered);
        } catch (RuntimeException exception) {
            Log.e(TAG, "Unable to send SMS reminder", exception);
        }
    }
}
