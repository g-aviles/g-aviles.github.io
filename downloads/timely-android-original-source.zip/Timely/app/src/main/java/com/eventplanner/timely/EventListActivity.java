package com.eventplanner.timely;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Displays account-owned events in Day, Week, and Month calendar views. */
public class EventListActivity extends AppCompatActivity {
    private enum ViewMode {
        DAY,
        WEEK,
        MONTH;

        static ViewMode fromPosition(int position) {
            ViewMode[] modes = values();
            return position >= 0 && position < modes.length ? modes[position] : DAY;
        }
    }

    private RecyclerView recyclerView;
    private EventAdapter adapter;
    private TextView currentRange;
    private EventDatabaseHelper database;
    private LocalDate focusedDate;
    private ViewMode viewMode = ViewMode.DAY;
    private String ownerEmail;
    private ActivityResultLauncher<Intent> eventLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ownerEmail = SessionManager.getAuthenticatedEmail(this);
        if (ownerEmail.isEmpty()) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }
        setContentView(R.layout.activity_events_list);
        focusedDate = LocalDate.now();
        database = new EventDatabaseHelper(this);
        database.claimUnownedEvents(ownerEmail);
        eventLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(), result -> {
                    // onResume performs the single refresh after the event screen closes.
                });
        initializeViews();
        setupSpinner();
        setupNavigation();
        setupButtons();
        updateRangeAndLoad();
    }

    private void initializeViews() {
        currentRange = findViewById(R.id.tvCurrentRange);
        recyclerView = findViewById(R.id.recyclerEvents);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    private void setupSpinner() {
        Spinner spinner = findViewById(R.id.spinnerFilter);
        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(
                this, R.array.calendar_views, android.R.layout.simple_spinner_item);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(spinnerAdapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                viewMode = ViewMode.fromPosition(position);
                updateRangeAndLoad();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                viewMode = ViewMode.DAY;
            }
        });
    }

    private void setupNavigation() {
        Button previous = findViewById(R.id.btnPrev);
        Button next = findViewById(R.id.btnNext);
        previous.setOnClickListener(view -> navigate(-1));
        next.setOnClickListener(view -> navigate(1));
    }

    private void setupButtons() {
        FloatingActionButton settings = findViewById(R.id.btnSettings);
        settings.setOnClickListener(view -> startActivity(new Intent(this, SettingsActivity.class)));
        FloatingActionButton add = findViewById(R.id.btnAdd);
        add.setOnClickListener(view -> eventLauncher.launch(new Intent(this, EventActivity.class)));
    }

    private void navigate(int direction) {
        switch (viewMode) {
            case DAY:
                focusedDate = focusedDate.plusDays(direction);
                break;
            case WEEK:
                focusedDate = focusedDate.plusWeeks(direction);
                break;
            case MONTH:
                focusedDate = focusedDate.plusMonths(direction);
                break;
            default:
                focusedDate = LocalDate.now();
        }
        updateRangeAndLoad();
    }

    private void updateRangeAndLoad() {
        switch (viewMode) {
            case DAY:
                currentRange.setText(DateTimeFormatter.ofPattern(
                        "EEE, MMM d, uuuu", Locale.getDefault()).format(focusedDate));
                break;
            case WEEK:
                LocalDate first = startOfWeek(focusedDate);
                LocalDate last = first.plusDays(6);
                DateTimeFormatter shortDate = DateTimeFormatter.ofPattern("MMM d", Locale.getDefault());
                currentRange.setText(getString(
                        R.string.date_range, shortDate.format(first), shortDate.format(last)));
                break;
            case MONTH:
                currentRange.setText(DateTimeFormatter.ofPattern(
                        "MMMM uuuu", Locale.getDefault()).format(focusedDate));
                break;
            default:
                currentRange.setText("");
        }
        loadEvents();
    }

    private void loadEvents() {
        ArrayList<Event> events = database.getAllEvents(ownerEmail);
        ArrayList<EventListItem> rows;
        switch (viewMode) {
            case DAY:
                rows = buildDayRows(events);
                break;
            case WEEK:
                rows = buildWeekRows(events);
                break;
            case MONTH:
                rows = buildMonthRows(events);
                break;
            default:
                rows = new ArrayList<>();
        }
        if (adapter == null) {
            adapter = new EventAdapter(this, rows, this::deleteEvent);
            recyclerView.setAdapter(adapter);
        } else {
            adapter.updateDisplayData(rows);
        }
    }

    private ArrayList<EventListItem> buildDayRows(List<Event> events) {
        Map<Integer, List<Event>> byHour = new LinkedHashMap<>();
        for (int hour = 0; hour < 24; hour++) {
            byHour.put(hour, new ArrayList<>());
        }
        for (Event event : events) {
            if (event.getStartDate().equals(focusedDate)) {
                byHour.get(event.getStartHour()).add(event);
            }
        }
        ArrayList<EventListItem> rows = new ArrayList<>();
        DateTimeFormatter hourFormat = DateTimeFormatter.ofPattern("h a", Locale.getDefault());
        for (Map.Entry<Integer, List<Event>> entry : byHour.entrySet()) {
            rows.add(EventListItem.header(hourFormat.format(
                    java.time.LocalTime.of(entry.getKey(), 0))));
            for (Event event : entry.getValue()) {
                rows.add(EventListItem.event(event));
            }
        }
        return rows;
    }

    private ArrayList<EventListItem> buildWeekRows(List<Event> events) {
        LocalDate first = startOfWeek(focusedDate);
        Map<LocalDate, List<Event>> byDate = new LinkedHashMap<>();
        for (int day = 0; day < 7; day++) {
            byDate.put(first.plusDays(day), new ArrayList<>());
        }
        for (Event event : events) {
            List<Event> dateEvents = byDate.get(event.getStartDate());
            if (dateEvents != null) {
                dateEvents.add(event);
            }
        }
        ArrayList<EventListItem> rows = new ArrayList<>();
        DateTimeFormatter headerFormat = DateTimeFormatter.ofPattern("EEE, MMM d", Locale.getDefault());
        for (Map.Entry<LocalDate, List<Event>> entry : byDate.entrySet()) {
            rows.add(EventListItem.header(headerFormat.format(entry.getKey())));
            for (Event event : entry.getValue()) {
                rows.add(EventListItem.event(event));
            }
        }
        return rows;
    }

    private ArrayList<EventListItem> buildMonthRows(List<Event> events) {
        ArrayList<EventListItem> rows = new ArrayList<>();
        for (Event event : events) {
            LocalDate date = event.getStartDate();
            if (date.getYear() == focusedDate.getYear()
                    && date.getMonth() == focusedDate.getMonth()) {
                rows.add(EventListItem.event(event));
            }
        }
        return rows;
    }

    private LocalDate startOfWeek(LocalDate date) {
        java.time.DayOfWeek firstDay = java.time.temporal.WeekFields
                .of(Locale.getDefault()).getFirstDayOfWeek();
        return date.with(TemporalAdjusters.previousOrSame(firstDay));
    }

    private void deleteEvent(Event event) {
        if (!database.deleteEvent(event.getId(), ownerEmail)) {
            Toast.makeText(this, R.string.event_delete_failed, Toast.LENGTH_SHORT).show();
            return;
        }
        ReminderScheduler.cancel(this, event.getId(), ownerEmail);
        Toast.makeText(this, R.string.event_deleted, Toast.LENGTH_SHORT).show();
        loadEvents();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (database != null && ownerEmail != null && !ownerEmail.isEmpty()) {
            loadEvents();
        }
    }

    @Override
    protected void onDestroy() {
        if (database != null) {
            database.close();
        }
        super.onDestroy();
    }
}
