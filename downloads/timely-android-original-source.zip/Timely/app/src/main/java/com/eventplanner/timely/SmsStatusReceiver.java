package com.eventplanner.timely;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsManager;
import android.util.Log;

/** Records whether an SMS reminder was sent or delivered. */
public class SmsStatusReceiver extends BroadcastReceiver {
    private static final String TAG = "SmsStatusReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        int eventId = intent.getIntExtra(AppConstants.EXTRA_EVENT_ID, -1);
        if (AppConstants.ACTION_SMS_DELIVERED.equals(intent.getAction())) {
            if (getResultCode() == Activity.RESULT_OK) {
                Log.i(TAG, "SMS reminder delivered for event " + eventId);
            } else {
                Log.w(TAG, "SMS reminder delivery failed for event " + eventId);
            }
            return;
        }

        if (getResultCode() == Activity.RESULT_OK) {
            Log.i(TAG, "SMS reminder sent for event " + eventId);
        } else if (getResultCode() == SmsManager.RESULT_ERROR_NO_SERVICE) {
            Log.w(TAG, "SMS service unavailable for event " + eventId);
        } else {
            Log.w(TAG, "SMS reminder failed for event " + eventId + " with result " + getResultCode());
        }
    }
}
