package com.eventplanner.timely;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

/** Creates and cancels alarms using the event ID as their stable identity. */
public final class ReminderScheduler {
    private static final String TAG = "ReminderScheduler";

    private ReminderScheduler() {
    }

    public static boolean schedule(Context context, Event event) {
        if (event.getStartMillis() <= System.currentTimeMillis()) {
            return false;
        }
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) {
            Log.e(TAG, "Alarm service is unavailable");
            return false;
        }

        PendingIntent pendingIntent = reminderPendingIntent(context, event, PendingIntent.FLAG_UPDATE_CURRENT);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
                alarmManager.set(AlarmManager.RTC_WAKEUP, event.getStartMillis(), pendingIntent);
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, event.getStartMillis(), pendingIntent);
            }
            return true;
        } catch (SecurityException exception) {
            Log.e(TAG, "Unable to schedule reminder", exception);
            return false;
        }
    }

    public static void cancel(Context context, int eventId, String ownerEmail) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) {
            return;
        }
        Intent intent = new Intent(context, ReminderReceiver.class)
                .putExtra(AppConstants.EXTRA_EVENT_ID, eventId)
                .putExtra(AppConstants.EXTRA_OWNER_EMAIL, SessionManager.normalizeEmail(ownerEmail));
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                eventId,
                intent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_NO_CREATE);
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent);
            pendingIntent.cancel();
        }
    }

    private static PendingIntent reminderPendingIntent(Context context, Event event, int updateFlag) {
        Intent intent = new Intent(context, ReminderReceiver.class)
                .putExtra(AppConstants.EXTRA_EVENT_ID, event.getId())
                .putExtra(AppConstants.EXTRA_OWNER_EMAIL, event.getOwnerEmail());
        return PendingIntent.getBroadcast(
                context,
                event.getId(),
                intent,
                PendingIntent.FLAG_IMMUTABLE | updateFlag);
    }
}
