package com.eventplanner.timely;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

/** Binds strongly typed calendar header and event rows. */
public class EventAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final int TYPE_HEADER = 0;
    private static final int TYPE_EVENT = 1;

    public interface OnDeleteRequestedListener {
        void onDeleteRequested(Event event);
    }

    private final Context context;
    private final OnDeleteRequestedListener deleteListener;
    private ArrayList<EventListItem> items;

    public EventAdapter(Context context, ArrayList<EventListItem> items,
                        OnDeleteRequestedListener deleteListener) {
        this.context = context;
        this.items = items;
        this.deleteListener = deleteListener;
    }

    @Override
    public int getItemViewType(int position) {
        return items.get(position).getType() == EventListItem.Type.HEADER
                ? TYPE_HEADER
                : TYPE_EVENT;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        if (viewType == TYPE_HEADER) {
            return new HeaderViewHolder(inflater.inflate(R.layout.event_header_item, parent, false));
        }
        return new EventViewHolder(inflater.inflate(R.layout.event_grid_item, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        EventListItem item = items.get(position);
        if (holder instanceof HeaderViewHolder) {
            ((HeaderViewHolder) holder).header.setText(item.getHeader());
            return;
        }

        Event event = item.getEvent();
        if (event == null) {
            return;
        }
        EventViewHolder eventHolder = (EventViewHolder) holder;
        eventHolder.title.setText(event.getTitle());
        eventHolder.type.setText(event.getType());
        eventHolder.time.setText(context.getString(
                R.string.event_time_range, event.getStartTime(), event.getEndTime()));
        eventHolder.itemView.setOnClickListener(view -> {
            Intent intent = new Intent(context, EventActivity.class);
            intent.putExtra(AppConstants.EXTRA_EVENT_ID, event.getId());
            context.startActivity(intent);
        });
        eventHolder.itemView.setOnLongClickListener(view -> {
            int currentPosition = eventHolder.getBindingAdapterPosition();
            if (currentPosition == RecyclerView.NO_POSITION) {
                return true;
            }
            EventListItem currentItem = items.get(currentPosition);
            Event currentEvent = currentItem.getEvent();
            if (currentEvent == null) {
                return true;
            }
            new AlertDialog.Builder(context)
                    .setTitle(R.string.delete_event_title)
                    .setMessage(R.string.delete_event_confirmation)
                    .setPositiveButton(R.string.yes, (dialog, which) ->
                            deleteListener.onDeleteRequested(currentEvent))
                    .setNegativeButton(R.string.cancel, null)
                    .show();
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public void updateDisplayData(ArrayList<EventListItem> newItems) {
        items = newItems;
        notifyDataSetChanged();
    }

    static class HeaderViewHolder extends RecyclerView.ViewHolder {
        final TextView header;

        HeaderViewHolder(@NonNull View itemView) {
            super(itemView);
            header = itemView.findViewById(R.id.tvHeader);
        }
    }

    static class EventViewHolder extends RecyclerView.ViewHolder {
        final TextView time;
        final TextView title;
        final TextView type;

        EventViewHolder(@NonNull View itemView) {
            super(itemView);
            time = itemView.findViewById(R.id.tvTime);
            title = itemView.findViewById(R.id.tvTitle);
            type = itemView.findViewById(R.id.tvType);
        }
    }
}
