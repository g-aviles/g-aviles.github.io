package com.eventplanner.timely;

import android.content.Context;
import android.content.SharedPreferences;

/** Stores the currently authenticated local account. */
public final class SessionManager {
    private static final String PREFS_NAME = "session_pref";
    private static final String KEY_EMAIL = "authenticated_email";

    private SessionManager() {
    }

    public static void signIn(Context context, String email) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_EMAIL, normalizeEmail(email))
                .apply();
    }

    public static String getAuthenticatedEmail(Context context) {
        SharedPreferences preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return preferences.getString(KEY_EMAIL, "");
    }

    public static void signOut(Context context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .remove(KEY_EMAIL)
                .apply();
    }

    public static String normalizeEmail(String email) {
        return email == null ? "" : email.trim().toLowerCase(java.util.Locale.ROOT);
    }
}
