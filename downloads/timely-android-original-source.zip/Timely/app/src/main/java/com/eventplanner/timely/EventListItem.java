package com.eventplanner.timely;

/** Strongly typed row model for calendar headers and events. */
public final class EventListItem {
    public enum Type {
        HEADER,
        EVENT
    }

    private final Type type;
    private final String header;
    private final Event event;

    private EventListItem(Type type, String header, Event event) {
        this.type = type;
        this.header = header;
        this.event = event;
    }

    public static EventListItem header(String label) {
        return new EventListItem(Type.HEADER, label, null);
    }

    public static EventListItem event(Event event) {
        return new EventListItem(Type.EVENT, null, event);
    }

    public Type getType() {
        return type;
    }

    public String getHeader() {
        return header;
    }

    public Event getEvent() {
        return event;
    }
}
