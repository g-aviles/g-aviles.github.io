import 'package:flutter_test/flutter_test.dart';
import 'package:timely_flutter/models/event.dart';

void main() {
  test('event round-trips through its database map', () {
    final event = Event(
      id: 7,
      ownerEmail: 'USER@EXAMPLE.COM',
      title: ' Planning ',
      start: DateTime(2026, 7, 20, 9),
      end: DateTime(2026, 7, 20, 10),
      type: 'Meeting',
      notes: ' Agenda ',
      reminderMinutes: 30,
    );

    final restored = Event.fromMap(event.toMap());

    expect(restored.id, 7);
    expect(restored.ownerEmail, 'user@example.com');
    expect(restored.title, 'Planning');
    expect(restored.start, DateTime(2026, 7, 20, 9));
    expect(restored.end, DateTime(2026, 7, 20, 10));
    expect(restored.notes, 'Agenda');
    expect(restored.reminderTime, DateTime(2026, 7, 20, 8, 30));
  });
}
