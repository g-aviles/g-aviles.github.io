import 'package:flutter_test/flutter_test.dart';
import 'package:timely_flutter/services/password_service.dart';

void main() {
  test('PBKDF2 hashes use random salts and verify correctly', () async {
    const password = 'correct horse battery staple';
    final first = await PasswordService.hash(password);
    final second = await PasswordService.hash(password);

    expect(first.hash, isNot(second.hash));
    expect(first.salt, isNot(second.salt));
    expect(
      await PasswordService.verify(password, first.hash, first.salt),
      isTrue,
    );
    expect(
      await PasswordService.verify('wrong password', first.hash, first.salt),
      isFalse,
    );
  });
}
