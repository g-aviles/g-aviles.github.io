class Event {
  const Event({
    this.id,
    required this.ownerEmail,
    required this.title,
    required this.start,
    required this.end,
    required this.type,
    required this.notes,
    this.reminderMinutes = 15,
  });

  final int? id;
  final String ownerEmail;
  final String title;
  final DateTime start;
  final DateTime end;
  final String type;
  final String notes;
  final int reminderMinutes;

  DateTime get reminderTime =>
      start.subtract(Duration(minutes: reminderMinutes));

  Event copyWith({
    int? id,
    String? ownerEmail,
    String? title,
    DateTime? start,
    DateTime? end,
    String? type,
    String? notes,
    int? reminderMinutes,
  }) {
    return Event(
      id: id ?? this.id,
      ownerEmail: ownerEmail ?? this.ownerEmail,
      title: title ?? this.title,
      start: start ?? this.start,
      end: end ?? this.end,
      type: type ?? this.type,
      notes: notes ?? this.notes,
      reminderMinutes: reminderMinutes ?? this.reminderMinutes,
    );
  }

  Map<String, Object?> toMap() => {
    if (id != null) 'id': id,
    'owner_email': ownerEmail.trim().toLowerCase(),
    'title': title.trim(),
    'start_ms': start.millisecondsSinceEpoch,
    'end_ms': end.millisecondsSinceEpoch,
    'type': type,
    'notes': notes.trim(),
    'reminder_minutes': reminderMinutes,
  };

  factory Event.fromMap(Map<String, Object?> map) {
    return Event(
      id: map['id'] as int,
      ownerEmail: map['owner_email'] as String,
      title: map['title'] as String,
      start: DateTime.fromMillisecondsSinceEpoch(map['start_ms'] as int),
      end: DateTime.fromMillisecondsSinceEpoch(map['end_ms'] as int),
      type: map['type'] as String,
      notes: map['notes'] as String? ?? '',
      reminderMinutes: map['reminder_minutes'] as int? ?? 15,
    );
  }
}
