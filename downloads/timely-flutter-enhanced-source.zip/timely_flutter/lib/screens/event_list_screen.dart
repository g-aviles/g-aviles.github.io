import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/event.dart';
import '../services/app_database.dart';
import '../services/notification_service.dart';
import '../services/settings_service.dart';
import '../services/sms_service.dart';
import '../widgets/event_card.dart';
import 'event_editor_screen.dart';
import 'settings_screen.dart';

enum CalendarView { day, week, month }

class EventListScreen extends StatefulWidget {
  const EventListScreen({
    super.key,
    required this.email,
    required this.onSignOut,
  });

  final String email;
  final VoidCallback onSignOut;

  @override
  State<EventListScreen> createState() => _EventListScreenState();
}

class _EventListScreenState extends State<EventListScreen> {
  CalendarView _view = CalendarView.day;
  DateTime _focusedDate = DateUtils.dateOnly(DateTime.now());
  List<Event> _events = const [];
  UserSettings _settings = const UserSettings(
    notificationsEnabled: false,
    smsEnabled: false,
    phoneNumber: '',
  );
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final results = await Future.wait([
      AppDatabase.instance.eventsFor(widget.email),
      SettingsService.load(widget.email),
    ]);
    if (!mounted) return;
    setState(() {
      _events = results[0] as List<Event>;
      _settings = results[1] as UserSettings;
      _loading = false;
    });
  }

  List<Event> get _visibleEvents {
    return _events
        .where((event) {
          final date = DateUtils.dateOnly(event.start);
          switch (_view) {
            case CalendarView.day:
              return DateUtils.isSameDay(date, _focusedDate);
            case CalendarView.week:
              final first = _startOfWeek(_focusedDate);
              final last = first.add(const Duration(days: 7));
              return !date.isBefore(first) && date.isBefore(last);
            case CalendarView.month:
              return date.year == _focusedDate.year &&
                  date.month == _focusedDate.month;
          }
        })
        .toList(growable: false);
  }

  DateTime _startOfWeek(DateTime date) =>
      DateUtils.dateOnly(date).subtract(Duration(days: date.weekday - 1));

  void _move(int direction) {
    setState(() {
      _focusedDate = switch (_view) {
        CalendarView.day => _focusedDate.add(Duration(days: direction)),
        CalendarView.week => _focusedDate.add(Duration(days: 7 * direction)),
        CalendarView.month => DateTime(
          _focusedDate.year,
          _focusedDate.month + direction,
          1,
        ),
      };
    });
  }

  String get _rangeLabel {
    switch (_view) {
      case CalendarView.day:
        return DateFormat('EEE, MMM d, y').format(_focusedDate);
      case CalendarView.week:
        final first = _startOfWeek(_focusedDate);
        final last = first.add(const Duration(days: 6));
        return '${DateFormat('MMM d').format(first)}–'
            '${DateFormat('MMM d, y').format(last)}';
      case CalendarView.month:
        return DateFormat('MMMM y').format(_focusedDate);
    }
  }

  Future<void> _chooseFocusedDate() async {
    final value = await showDatePicker(
      context: context,
      initialDate: _focusedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (value != null) setState(() => _focusedDate = value);
  }

  Future<void> _editEvent([Event? existing]) async {
    final event = await Navigator.push<Event>(
      context,
      MaterialPageRoute(
        builder: (_) => EventEditorScreen(
          ownerEmail: widget.email,
          event: existing,
          initialDate: _focusedDate,
        ),
      ),
    );
    if (event == null) return;
    try {
      if (existing?.id != null) {
        await NotificationService.instance.cancel(existing!.id);
      }
      final saved = await AppDatabase.instance.saveEvent(event);
      if (_settings.notificationsEnabled) {
        await NotificationService.instance.schedule(saved);
      }
      await _load();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              existing == null ? 'Event created.' : 'Event updated.',
            ),
          ),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('The event could not be saved.')),
        );
      }
    }
  }

  Future<void> _deleteEvent(Event event) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete event?'),
        content: Text('Delete “${event.title}”?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    final deleted = await AppDatabase.instance.deleteEvent(event);
    if (deleted) {
      await NotificationService.instance.cancel(event.id);
      await _load();
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(deleted ? 'Event deleted.' : 'Event was not deleted.'),
        ),
      );
    }
  }

  Future<void> _openSettings() async {
    final settings = await Navigator.push<UserSettings>(
      context,
      MaterialPageRoute(builder: (_) => SettingsScreen(email: widget.email)),
    );
    if (settings == null || !mounted) return;
    setState(() => _settings = settings);
    if (settings.notificationsEnabled) {
      for (final event in _events) {
        await NotificationService.instance.schedule(event);
      }
    }
  }

  Future<void> _composeMessage(Event event) async {
    final launched = await SmsService.compose(_settings.phoneNumber, event);
    if (!launched && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No messaging application is available.')),
      );
    }
  }

  List<Widget> _eventSections() {
    final grouped = <DateTime, List<Event>>{};
    for (final event in _visibleEvents) {
      final date = DateUtils.dateOnly(event.start);
      grouped.putIfAbsent(date, () => []).add(event);
    }
    if (grouped.isEmpty) {
      return [
        const Expanded(
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.event_busy, size: 56),
                SizedBox(height: 12),
                Text('No events in this period.'),
              ],
            ),
          ),
        ),
      ];
    }
    final children = <Widget>[];
    for (final entry in grouped.entries) {
      children.add(
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
          child: Text(
            DateFormat('EEEE, MMMM d').format(entry.key),
            style: Theme.of(context).textTheme.titleMedium,
          ),
        ),
      );
      children.addAll(
        entry.value.map(
          (event) => EventCard(
            event: event,
            onEdit: () => _editEvent(event),
            onDelete: () => _deleteEvent(event),
            onMessage:
                _settings.smsEnabled && _settings.phoneNumber.trim().isNotEmpty
                ? () => _composeMessage(event)
                : null,
          ),
        ),
      );
    }
    return [Expanded(child: ListView(children: children))];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Timely'),
        actions: [
          IconButton(
            tooltip: 'Settings',
            onPressed: _openSettings,
            icon: const Icon(Icons.settings_outlined),
          ),
          PopupMenuButton<String>(
            tooltip: 'Account',
            onSelected: (value) {
              if (value == 'logout') widget.onSignOut();
            },
            itemBuilder: (_) => [
              PopupMenuItem(enabled: false, child: Text(widget.email)),
              const PopupMenuItem(value: 'logout', child: Text('Sign out')),
            ],
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
                  child: SegmentedButton<CalendarView>(
                    segments: const [
                      ButtonSegment(
                        value: CalendarView.day,
                        label: Text('Day'),
                      ),
                      ButtonSegment(
                        value: CalendarView.week,
                        label: Text('Week'),
                      ),
                      ButtonSegment(
                        value: CalendarView.month,
                        label: Text('Month'),
                      ),
                    ],
                    selected: {_view},
                    onSelectionChanged: (value) =>
                        setState(() => _view = value.first),
                  ),
                ),
                Row(
                  children: [
                    IconButton(
                      tooltip: 'Previous period',
                      onPressed: () => _move(-1),
                      icon: const Icon(Icons.chevron_left),
                    ),
                    Expanded(
                      child: TextButton(
                        onPressed: _chooseFocusedDate,
                        child: Text(
                          _rangeLabel,
                          textAlign: TextAlign.center,
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                      ),
                    ),
                    IconButton(
                      tooltip: 'Next period',
                      onPressed: () => _move(1),
                      icon: const Icon(Icons.chevron_right),
                    ),
                  ],
                ),
                ..._eventSections(),
              ],
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _editEvent(),
        icon: const Icon(Icons.add),
        label: const Text('Event'),
      ),
    );
  }
}
