import 'package:flutter/material.dart';

import '../services/notification_service.dart';
import '../services/settings_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key, required this.email});

  final String email;

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _formKey = GlobalKey<FormState>();
  final _phoneController = TextEditingController();
  bool _notificationsEnabled = true;
  bool _smsEnabled = false;
  bool _loading = true;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final settings = await SettingsService.load(widget.email);
    if (!mounted) return;
    setState(() {
      _notificationsEnabled = settings.notificationsEnabled;
      _smsEnabled = settings.smsEnabled;
      _phoneController.text = settings.phoneNumber;
      _loading = false;
    });
  }

  @override
  void dispose() {
    _phoneController.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    var notificationsEnabled = _notificationsEnabled;
    if (notificationsEnabled) {
      final granted = await NotificationService.instance.requestPermission();
      if (!granted && mounted) {
        notificationsEnabled = false;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Notification permission was not granted.'),
          ),
        );
      }
    } else {
      await NotificationService.instance.cancelAll();
    }
    final settings = UserSettings(
      notificationsEnabled: notificationsEnabled,
      smsEnabled: _smsEnabled,
      phoneNumber: _phoneController.text.trim(),
    );
    await SettingsService.save(widget.email, settings);
    if (!mounted) return;
    setState(() {
      _notificationsEnabled = notificationsEnabled;
      _saving = false;
    });
    Navigator.pop(context, settings);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Form(
              key: _formKey,
              child: ListView(
                padding: const EdgeInsets.all(20),
                children: [
                  Text(
                    'Reminders',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 8),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Local notifications'),
                    subtitle: const Text(
                      'Show an Android or iPhone reminder before each event.',
                    ),
                    value: _notificationsEnabled,
                    onChanged: (value) =>
                        setState(() => _notificationsEnabled = value),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('SMS composition'),
                    subtitle: const Text(
                      'Show a message button that opens a prefilled text. '
                      'The user approves every message on iPhone.',
                    ),
                    value: _smsEnabled,
                    onChanged: (value) => setState(() => _smsEnabled = value),
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _phoneController,
                    enabled: _smsEnabled,
                    keyboardType: TextInputType.phone,
                    autofillHints: const [AutofillHints.telephoneNumber],
                    decoration: const InputDecoration(
                      labelText: 'Reminder phone number',
                      prefixIcon: Icon(Icons.phone_outlined),
                      hintText: '+1 555 123 4567',
                    ),
                    validator: (value) {
                      if (!_smsEnabled) return null;
                      final digits = (value ?? '').replaceAll(
                        RegExp(r'\D'),
                        '',
                      );
                      return digits.length < 10 || digits.length > 15
                          ? 'Enter a valid phone number.'
                          : null;
                    },
                  ),
                  const SizedBox(height: 24),
                  FilledButton.icon(
                    onPressed: _saving ? null : _save,
                    icon: const Icon(Icons.save),
                    label: Text(_saving ? 'Saving…' : 'Save settings'),
                  ),
                  const SizedBox(height: 24),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Text(
                        'Signed in as ${widget.email}\n\n'
                        'Accounts and events are stored locally on this device.',
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}
