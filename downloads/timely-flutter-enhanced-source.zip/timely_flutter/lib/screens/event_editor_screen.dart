import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/event.dart';

class EventEditorScreen extends StatefulWidget {
  const EventEditorScreen({
    super.key,
    required this.ownerEmail,
    this.event,
    this.initialDate,
  });

  final String ownerEmail;
  final Event? event;
  final DateTime? initialDate;

  @override
  State<EventEditorScreen> createState() => _EventEditorScreenState();
}

class _EventEditorScreenState extends State<EventEditorScreen> {
  static const _types = [
    'Appointment',
    'Meeting',
    'Personal',
    'School',
    'Other',
  ];
  static const _reminderOptions = [5, 10, 15, 30, 60, 1440];

  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _titleController;
  late final TextEditingController _notesController;
  late DateTime _date;
  late TimeOfDay _startTime;
  late TimeOfDay _endTime;
  late String _type;
  late int _reminderMinutes;

  @override
  void initState() {
    super.initState();
    final existing = widget.event;
    final now = DateTime.now();
    final base = existing?.start ?? widget.initialDate ?? now;
    _date = DateTime(base.year, base.month, base.day);
    _startTime = existing == null
        ? TimeOfDay(hour: now.hour + (now.hour < 23 ? 1 : 0), minute: 0)
        : TimeOfDay.fromDateTime(existing.start);
    _endTime = existing == null
        ? TimeOfDay(hour: (_startTime.hour + 1) % 24, minute: 0)
        : TimeOfDay.fromDateTime(existing.end);
    _type = existing?.type ?? _types.first;
    _reminderMinutes = existing?.reminderMinutes ?? 15;
    _titleController = TextEditingController(text: existing?.title ?? '');
    _notesController = TextEditingController(text: existing?.notes ?? '');
  }

  @override
  void dispose() {
    _titleController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  DateTime _combine(TimeOfDay time) =>
      DateTime(_date.year, _date.month, _date.day, time.hour, time.minute);

  Future<void> _pickDate() async {
    final value = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (value != null) setState(() => _date = value);
  }

  Future<void> _pickTime({required bool start}) async {
    final value = await showTimePicker(
      context: context,
      initialTime: start ? _startTime : _endTime,
    );
    if (value != null) {
      setState(() => start ? _startTime = value : _endTime = value);
    }
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    final start = _combine(_startTime);
    final end = _combine(_endTime);
    if (!end.isAfter(start)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('End time must be after start time.')),
      );
      return;
    }
    Navigator.pop(
      context,
      Event(
        id: widget.event?.id,
        ownerEmail: widget.ownerEmail,
        title: _titleController.text,
        start: start,
        end: end,
        type: _type,
        notes: _notesController.text,
        reminderMinutes: _reminderMinutes,
      ),
    );
  }

  String _reminderLabel(int minutes) {
    if (minutes == 1440) return '1 day before';
    if (minutes == 60) return '1 hour before';
    return '$minutes minutes before';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.event == null ? 'New event' : 'Edit event'),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            TextFormField(
              controller: _titleController,
              autofocus: widget.event == null,
              textCapitalization: TextCapitalization.sentences,
              decoration: const InputDecoration(
                labelText: 'Title',
                prefixIcon: Icon(Icons.title),
              ),
              validator: (value) => (value?.trim().isEmpty ?? true)
                  ? 'Enter an event title.'
                  : null,
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              initialValue: _type,
              decoration: const InputDecoration(
                labelText: 'Event type',
                prefixIcon: Icon(Icons.category_outlined),
              ),
              items: _types
                  .map(
                    (type) => DropdownMenuItem(value: type, child: Text(type)),
                  )
                  .toList(),
              onChanged: (value) => setState(() => _type = value!),
            ),
            const SizedBox(height: 16),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.calendar_today),
              title: const Text('Date'),
              subtitle: Text(DateFormat.yMMMMd().format(_date)),
              trailing: const Icon(Icons.chevron_right),
              onTap: _pickDate,
            ),
            Row(
              children: [
                Expanded(
                  child: ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.schedule),
                    title: const Text('Starts'),
                    subtitle: Text(_startTime.format(context)),
                    onTap: () => _pickTime(start: true),
                  ),
                ),
                Expanded(
                  child: ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.schedule_outlined),
                    title: const Text('Ends'),
                    subtitle: Text(_endTime.format(context)),
                    onTap: () => _pickTime(start: false),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            DropdownButtonFormField<int>(
              initialValue: _reminderMinutes,
              decoration: const InputDecoration(
                labelText: 'Reminder',
                prefixIcon: Icon(Icons.notifications_outlined),
              ),
              items: _reminderOptions
                  .map(
                    (minutes) => DropdownMenuItem(
                      value: minutes,
                      child: Text(_reminderLabel(minutes)),
                    ),
                  )
                  .toList(),
              onChanged: (value) => setState(() => _reminderMinutes = value!),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _notesController,
              minLines: 3,
              maxLines: 6,
              textCapitalization: TextCapitalization.sentences,
              decoration: const InputDecoration(
                labelText: 'Notes',
                alignLabelWithHint: true,
                prefixIcon: Icon(Icons.notes),
              ),
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: _save,
              icon: const Icon(Icons.save),
              label: Text(
                widget.event == null ? 'Create event' : 'Save changes',
              ),
            ),
          ],
        ),
      ),
    );
  }
}
