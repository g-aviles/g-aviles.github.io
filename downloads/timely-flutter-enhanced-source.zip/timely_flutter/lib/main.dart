import 'package:flutter/material.dart';

import 'screens/event_list_screen.dart';
import 'screens/login_screen.dart';
import 'services/session_service.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const TimelyApp());
}

class TimelyApp extends StatefulWidget {
  const TimelyApp({super.key});

  @override
  State<TimelyApp> createState() => _TimelyAppState();
}

class _TimelyAppState extends State<TimelyApp> {
  String? _email;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _restoreSession();
  }

  Future<void> _restoreSession() async {
    final email = await SessionService.currentEmail();
    if (!mounted) return;
    setState(() {
      _email = email;
      _loading = false;
    });
  }

  Future<void> _signOut() async {
    await SessionService.signOut();
    if (mounted) setState(() => _email = null);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Timely',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF315C8C),
          brightness: Brightness.light,
        ),
        useMaterial3: true,
        inputDecorationTheme: const InputDecorationTheme(
          border: OutlineInputBorder(),
        ),
        cardTheme: const CardThemeData(
          clipBehavior: Clip.antiAlias,
          margin: EdgeInsets.zero,
        ),
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF7BA7D7),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
        inputDecorationTheme: const InputDecorationTheme(
          border: OutlineInputBorder(),
        ),
      ),
      home: _loading
          ? const Scaffold(body: Center(child: CircularProgressIndicator()))
          : _email == null
          ? LoginScreen(
              onAuthenticated: (email) => setState(() => _email = email),
            )
          : EventListScreen(email: _email!, onSignOut: _signOut),
    );
  }
}
