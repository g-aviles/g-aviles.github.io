import 'package:shared_preferences/shared_preferences.dart';

class SessionService {
  SessionService._();

  static const _emailKey = 'authenticated_email';

  static Future<String?> currentEmail() async {
    final preferences = await SharedPreferences.getInstance();
    return preferences.getString(_emailKey);
  }

  static Future<void> signIn(String email) async {
    final preferences = await SharedPreferences.getInstance();
    await preferences.setString(_emailKey, email.trim().toLowerCase());
  }

  static Future<void> signOut() async {
    final preferences = await SharedPreferences.getInstance();
    await preferences.remove(_emailKey);
  }
}
