import 'package:sqflite/sqflite.dart';

import '../models/event.dart';
import 'password_service.dart';

class AppDatabase {
  AppDatabase._();

  static final AppDatabase instance = AppDatabase._();
  Database? _database;

  Future<Database> get database async {
    return _database ??= await openDatabase(
      'timely.db',
      version: 1,
      onCreate: (database, version) async {
        await database.execute('''
          CREATE TABLE accounts(
            email TEXT PRIMARY KEY,
            password_hash TEXT NOT NULL,
            password_salt TEXT NOT NULL
          )
        ''');
        await database.execute('''
          CREATE TABLE events(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            owner_email TEXT NOT NULL,
            title TEXT NOT NULL,
            start_ms INTEGER NOT NULL,
            end_ms INTEGER NOT NULL,
            type TEXT NOT NULL,
            notes TEXT NOT NULL DEFAULT '',
            reminder_minutes INTEGER NOT NULL DEFAULT 15,
            FOREIGN KEY(owner_email) REFERENCES accounts(email) ON DELETE CASCADE
          )
        ''');
        await database.execute(
          'CREATE INDEX events_owner_start ON events(owner_email, start_ms)',
        );
      },
      onConfigure: (database) => database.execute('PRAGMA foreign_keys = ON'),
    );
  }

  Future<bool> createAccount(String email, String password) async {
    final normalizedEmail = email.trim().toLowerCase();
    final credentials = await PasswordService.hash(password);
    try {
      final db = await database;
      await db.insert('accounts', {
        'email': normalizedEmail,
        'password_hash': credentials.hash,
        'password_salt': credentials.salt,
      });
      return true;
    } on DatabaseException catch (error) {
      if (error.isUniqueConstraintError()) return false;
      rethrow;
    }
  }

  Future<bool> authenticate(String email, String password) async {
    final normalizedEmail = email.trim().toLowerCase();
    final db = await database;
    final rows = await db.query(
      'accounts',
      columns: ['password_hash', 'password_salt'],
      where: 'email = ?',
      whereArgs: [normalizedEmail],
      limit: 1,
    );
    if (rows.isEmpty) return false;
    return PasswordService.verify(
      password,
      rows.first['password_hash'] as String,
      rows.first['password_salt'] as String,
    );
  }

  Future<List<Event>> eventsFor(String ownerEmail) async {
    final db = await database;
    final rows = await db.query(
      'events',
      where: 'owner_email = ?',
      whereArgs: [ownerEmail.trim().toLowerCase()],
      orderBy: 'start_ms ASC, id ASC',
    );
    return rows.map(Event.fromMap).toList(growable: false);
  }

  Future<Event> saveEvent(Event event) async {
    final db = await database;
    if (event.id == null) {
      final id = await db.insert('events', event.toMap());
      return event.copyWith(id: id);
    }
    final values = event.toMap()..remove('id');
    final changed = await db.update(
      'events',
      values,
      where: 'id = ? AND owner_email = ?',
      whereArgs: [event.id, event.ownerEmail.trim().toLowerCase()],
    );
    if (changed != 1) {
      throw StateError('The event could not be updated.');
    }
    return event;
  }

  Future<bool> deleteEvent(Event event) async {
    if (event.id == null) return false;
    final db = await database;
    final deleted = await db.delete(
      'events',
      where: 'id = ? AND owner_email = ?',
      whereArgs: [event.id, event.ownerEmail.trim().toLowerCase()],
    );
    return deleted == 1;
  }
}
