import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';

class PasswordService {
  PasswordService._();

  static final Pbkdf2 _algorithm = Pbkdf2.hmacSha256(
    iterations: 120000,
    bits: 256,
  );

  static Future<({String hash, String salt})> hash(String password) async {
    final salt = Uint8List.fromList(
      List<int>.generate(16, (_) => Random.secure().nextInt(256)),
    );
    final key = await _algorithm.deriveKeyFromPassword(
      password: password,
      nonce: salt,
    );
    return (
      hash: base64Encode(await key.extractBytes()),
      salt: base64Encode(salt),
    );
  }

  static Future<bool> verify(
    String password,
    String encodedHash,
    String encodedSalt,
  ) async {
    try {
      final key = await _algorithm.deriveKeyFromPassword(
        password: password,
        nonce: base64Decode(encodedSalt),
      );
      final actual = await key.extractBytes();
      final expected = base64Decode(encodedHash);
      if (actual.length != expected.length) return false;
      var difference = 0;
      for (var index = 0; index < actual.length; index++) {
        difference |= actual[index] ^ expected[index];
      }
      return difference == 0;
    } on FormatException {
      return false;
    }
  }
}
