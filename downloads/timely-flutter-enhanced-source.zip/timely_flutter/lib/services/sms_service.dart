import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/event.dart';

class SmsService {
  SmsService._();

  static Future<bool> compose(String phoneNumber, Event event) async {
    final message =
        '${event.title} starts '
        '${DateFormat('EEE, MMM d, y at h:mm a').format(event.start)}.';
    final uri = Uri(
      scheme: 'sms',
      path: phoneNumber,
      queryParameters: {'body': message},
    );
    return launchUrl(uri, mode: LaunchMode.externalApplication);
  }
}
