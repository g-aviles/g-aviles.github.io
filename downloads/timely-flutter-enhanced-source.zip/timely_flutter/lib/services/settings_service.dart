import 'package:shared_preferences/shared_preferences.dart';

class UserSettings {
  const UserSettings({
    required this.notificationsEnabled,
    required this.smsEnabled,
    required this.phoneNumber,
  });

  final bool notificationsEnabled;
  final bool smsEnabled;
  final String phoneNumber;
}

class SettingsService {
  SettingsService._();

  static String _key(String email, String name) =>
      '${email.trim().toLowerCase()}_$name';

  static Future<UserSettings> load(String email) async {
    final preferences = await SharedPreferences.getInstance();
    return UserSettings(
      notificationsEnabled:
          preferences.getBool(_key(email, 'notifications')) ?? false,
      smsEnabled: preferences.getBool(_key(email, 'sms')) ?? false,
      phoneNumber: preferences.getString(_key(email, 'phone')) ?? '',
    );
  }

  static Future<void> save(String email, UserSettings settings) async {
    final preferences = await SharedPreferences.getInstance();
    await Future.wait([
      preferences.setBool(
        _key(email, 'notifications'),
        settings.notificationsEnabled,
      ),
      preferences.setBool(_key(email, 'sms'), settings.smsEnabled),
      preferences.setString(_key(email, 'phone'), settings.phoneNumber.trim()),
    ]);
  }
}
