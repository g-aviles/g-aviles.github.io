package com.eventplanner.timely

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
