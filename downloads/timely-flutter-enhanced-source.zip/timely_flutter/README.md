# Timely

Timely is a cross-platform event-planning application for Android and iOS.

## Features

- Local account creation and authentication
- Day, week, and month event views
- Event creation, editing, and deletion
- Persistent, account-scoped event storage
- Scheduled local notifications
- User-approved SMS reminder composition
- Light and dark appearance support

## Run the application

Install Flutter, connect a supported device or start an emulator, and run:

```sh
flutter pub get
flutter run
```

An iOS build requires macOS and Xcode.

## Verify the project

```sh
flutter analyze
flutter test
```
